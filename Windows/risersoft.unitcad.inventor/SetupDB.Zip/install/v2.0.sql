/*
Run this script on:

        DES1-PC\SQLEXPRESS.scriptdb.mxenggdb.new    -  This database will be modified

to synchronize it with:

        DES1-PC\SQLEXPRESS.mxenggdb

You are recommended to back up your database before running this script

Script created by SQL Compare version 8.1.0 from Red Gate Software Ltd at 06-Jan-2015 00:47:11

*/
SET NUMERIC_ROUNDABORT OFF
GO
SET ANSI_PADDING, ANSI_WARNINGS, CONCAT_NULL_YIELDS_NULL, ARITHABORT, QUOTED_IDENTIFIER, ANSI_NULLS ON
GO
IF EXISTS (SELECT * FROM tempdb..sysobjects WHERE id=OBJECT_ID('tempdb..#tmpErrors')) DROP TABLE #tmpErrors
GO
CREATE TABLE #tmpErrors (Error int)
GO
SET XACT_ABORT ON
GO
SET TRANSACTION ISOLATION LEVEL SERIALIZABLE
GO
BEGIN TRANSACTION
GO
PRINT N'Creating [dbo].[ItemVMSBOM]'
GO
CREATE TABLE [dbo].[ItemVMSBOM]
(
[ItemVMSBOMID] [int] NOT NULL IDENTITY(1, 1),
[ItemVMSID] [int] NULL,
[ChildItemVMSID] [int] NULL,
[Qty] [decimal] (18, 4) NULL,
[QtyFormula] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ItemVMSBOM] on [dbo].[ItemVMSBOM]'
GO
ALTER TABLE [dbo].[ItemVMSBOM] ADD CONSTRAINT [PK_ItemVMSBOM] PRIMARY KEY CLUSTERED  ([ItemVMSBOMID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CtlItems]'
GO
CREATE TABLE [dbo].[CtlItems]
(
[CtlItemID] [int] NOT NULL IDENTITY(1, 1),
[CtlItem] [varchar] (1000) NULL,
[GANameItem] [varchar] (1000) NULL,
[GARating] [varchar] (1000) NULL,
[GAMakesItem] [varchar] (1000) NULL,
[CtlCatID] [int] NULL,
[IsTB] [bit] NULL,
[Descrip] [varchar] (1000) NULL,
[Legend] [varchar] (1000) NULL,
[ItemCode] [varchar] (1000) NULL,
[CtlMake] [varchar] (1000) NULL,
[CatNum] [varchar] (1000) NULL,
[Purpose] [varchar] (1000) NULL,
[Remark] [varchar] (1000) NULL,
[Loc] [varchar] (1000) NULL,
[MtgCP] [varchar] (1000) NULL,
[MtgMB] [varchar] (1000) NULL,
[Price] [decimal] (18, 2) NULL,
[PriceLastUpdated] [datetime] NULL,
[MinLevel] [bit] NULL,
[ItemVMSID] [int] NULL,
[MtgCPID] [int] NULL,
[MtgMBID] [int] NULL,
[CompImageWD] [image] NULL,
[GADrg] [varchar] (1000) NULL,
[HasWD] AS (case when [compimagewd] IS NULL then (0) else (1) end),
[DontPrintInMatList] [bit] NULL,
[LugType] [int] NULL,
[LugHoleDia] [decimal] (18, 4) NULL,
[IsOld] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CtlItems] on [dbo].[CtlItems]'
GO
ALTER TABLE [dbo].[CtlItems] ADD CONSTRAINT [PK_CtlItems] PRIMARY KEY CLUSTERED  ([CtlItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CtlCat]'
GO
CREATE TABLE [dbo].[CtlCat]
(
[CtlCatID] [int] NOT NULL IDENTITY(1, 1),
[CtlCat] [varchar] (1000) NULL,
[GANameCat] [varchar] (1000) NULL,
[GAMakesCat] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__CtlCat__7DFBC087] on [dbo].[CtlCat]'
GO
ALTER TABLE [dbo].[CtlCat] ADD CONSTRAINT [PK__CtlCat__7DFBC087] PRIMARY KEY CLUSTERED  ([CtlCatID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtlTerm]'
GO
CREATE TABLE [dbo].[PIDCtlTerm]
(
[PIDCtlTermID] [int] NOT NULL IDENTITY(1, 1),
[PIDCtlID] [int] NULL,
[CtlItemTermSetID] [int] NULL,
[TerminalName] [varchar] (50) NULL,
[SortIndexCtl] [decimal] (18, 4) NULL,
[PIDCtlBusID] [int] NULL,
[SortIndexWire] [int] NULL,
[InternalTermID] [int] NULL,
[ExternalTermID] [int] NULL,
[PIDCtlTermID2] [int] NULL,
[WireLoopTermID] [int] NULL,
[PIDCtlCableIDFA] [int] NULL,
[ReduceBottomTBLine] [bit] NULL,
[CableDescripTBPrint] [varchar] (1000) NULL,
[LugQty] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtlTerm] on [dbo].[PIDCtlTerm]'
GO
ALTER TABLE [dbo].[PIDCtlTerm] ADD CONSTRAINT [PK_PIDCtlTerm] PRIMARY KEY CLUSTERED  ([PIDCtlTermID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtlPanel]'
GO
CREATE TABLE [dbo].[PIDCtlPanel]
(
[PIDCtlPanelID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[sortindex] [int] NULL,
[PanelCode] [varchar] (50) NULL,
[PanelName] [varchar] (1000) NULL,
[PanelType] [int] NULL,
[FieldIns] [bit] NULL,
[DrawingNoteTB] [text] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtlPanel] on [dbo].[PIDCtlPanel]'
GO
ALTER TABLE [dbo].[PIDCtlPanel] ADD CONSTRAINT [PK_PIDCtlPanel] PRIMARY KEY CLUSTERED  ([PIDCtlPanelID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_PIDCtlPanel] on [dbo].[PIDCtlPanel]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_PIDCtlPanel] ON [dbo].[PIDCtlPanel] ([PIDUnitID], [PanelCode])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtlBus]'
GO
CREATE TABLE [dbo].[PIDCtlBus]
(
[PIDCtlBusID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[WireNum] [varchar] (50) NULL,
[MultiTFMB] [bit] NULL,
[SQMM] [decimal] (18, 4) NULL,
[Color] [varchar] (50) NULL,
[WireItemID] [int] NULL,
[WireLength] [decimal] (18, 4) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtlWire] on [dbo].[PIDCtlBus]'
GO
ALTER TABLE [dbo].[PIDCtlBus] ADD CONSTRAINT [PK_PIDCtlWire] PRIMARY KEY CLUSTERED  ([PIDCtlBusID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_PIDCtlBus] on [dbo].[PIDCtlBus]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_PIDCtlBus] ON [dbo].[PIDCtlBus] ([PIDUnitID], [WireNum])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CtlItemTermSet]'
GO
CREATE TABLE [dbo].[CtlItemTermSet]
(
[CtlItemTermSetID] [int] NOT NULL IDENTITY(1, 1),
[CtlItemID] [int] NULL,
[CtlTerminalSetID] [int] NULL,
[TerminalNumXML] [varchar] (8000) NULL,
[TerminalNums] [varchar] (1000) NULL,
[SortIndex] [int] NULL,
[DevSepCable] [int] NULL,
[TerminalSetName] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CtlItemTermSet] on [dbo].[CtlItemTermSet]'
GO
ALTER TABLE [dbo].[CtlItemTermSet] ADD CONSTRAINT [PK_CtlItemTermSet] PRIMARY KEY CLUSTERED  ([CtlItemTermSetID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[StanSpecs]'
GO
CREATE TABLE [dbo].[StanSpecs]
(
[StanSpecID] [int] NOT NULL IDENTITY(1, 1),
[SpecNum] [nvarchar] (50) NULL,
[Amendment] [bit] NULL,
[Part] [nvarchar] (50) NULL,
[WriteAs] [nvarchar] (255) NULL,
[Title] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_Specs] on [dbo].[StanSpecs]'
GO
ALTER TABLE [dbo].[StanSpecs] ADD CONSTRAINT [PK_Specs] PRIMARY KEY CLUSTERED  ([StanSpecID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemSpecs]'
GO
CREATE TABLE [dbo].[ItemSpecs]
(
[StanSpecID] [int] NULL,
[ItemVMSID] [int] NULL,
[ItemSpecID] [int] NOT NULL IDENTITY(1, 1)
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ItemSpecs] on [dbo].[ItemSpecs]'
GO
ALTER TABLE [dbo].[ItemSpecs] ADD CONSTRAINT [PK_ItemSpecs] PRIMARY KEY CLUSTERED  ([ItemSpecID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Val]'
GO






CREATE       Function dbo.Val(@vcValue varchar(2000))

Returns float 

As

/* ----

' Purpose: Run like the Val Function in Access

' Example: set @A = dbo.Val('123 Main')

'----
' Parameters:
'
'   @vcValue = any string value (Usually with numbers)

'----
' Returns: the number at the beginning of the varchar
'----
*/



Begin 

Declare @fltValue float,
           @Pos int, 
         @Pos2 int
    
	set @vcvalue= rtrim(ltrim(@vcvalue))
	if @vcvalue in ('-','.','+') set @fltvalue=0
	else begin

		If IsNumeric(@vcValue) = 1 Set @fltValue = Cast(@vcValue As float)
		Else Begin
			Set @Pos2 = PatIndex('%[.]%', @vcValue) 
			Set @Pos = PatIndex('%[^0-9]%', @vcValue) 
	         
	          	if @Pos = @Pos2               
				Set @Pos2 = PatIndex('%[^0-9]%', substring(@vcValue,@Pos2+1,300))                               
			if @pos2 = len(@vcvalue) set @pos2=0
			if @Pos2 > 0 Set @Pos=  @Pos+@Pos2
	  
	 		If (@Pos > 1) and (isnumeric(left(@vcvalue,@pos-1))=1)
		           Set @fltValue = Cast(Left(@vcValue, @Pos - 1) As Float)
	        	Else Set @fltValue = 0
		end
        end
  
    Return @fltValue 
End







GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtlConn]'
GO
CREATE TABLE [dbo].[PIDCtlConn]
(
[PIDCtlConnID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[PIDCtlCableID] [int] NULL,
[PIDCtlTermID1] [int] NULL,
[PIDCtlTermID2] [int] NULL,
[CableCode] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtlConn] on [dbo].[PIDCtlConn]'
GO
ALTER TABLE [dbo].[PIDCtlConn] ADD CONSTRAINT [PK_PIDCtlConn] PRIMARY KEY CLUSTERED  ([PIDCtlConnID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtlCable]'
GO
CREATE TABLE [dbo].[PIDCtlCable]
(
[PIDCtlCableID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[CableName] [varchar] (50) NULL,
[IsParCable] [bit] NULL,
[NumCores] [int] NULL,
[SQMM] [decimal] (18, 4) NULL,
[OurScope] [bit] NULL,
[Loc1] [varchar] (50) NULL,
[Loc2] [varchar] (50) NULL,
[LocDescrip] [varchar] (1000) NULL,
[ConnCode] [varchar] (50) NULL,
[CableDescripTB] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtlCable] on [dbo].[PIDCtlCable]'
GO
ALTER TABLE [dbo].[PIDCtlCable] ADD CONSTRAINT [PK_PIDCtlCable] PRIMARY KEY CLUSTERED  ([PIDCtlCableID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CtlMtg]'
GO
CREATE TABLE [dbo].[CtlMtg]
(
[CtlMtgID] [int] NOT NULL IDENTITY(1, 1),
[MtgCode] [varchar] (50) NULL,
[MB] [bit] NULL,
[CP] [bit] NULL,
[Descrip] [varchar] (1000) NULL,
[ContentRTFzip] [image] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CtlMtg] on [dbo].[CtlMtg]'
GO
ALTER TABLE [dbo].[CtlMtg] ADD CONSTRAINT [PK_CtlMtg] PRIMARY KEY CLUSTERED  ([CtlMtgID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_CtlMtg] on [dbo].[CtlMtg]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CtlMtg] ON [dbo].[CtlMtg] ([MtgCode])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFDesBOMTank]'
GO
CREATE TABLE [dbo].[TFDesBOMTank]
(
[TFDesBOMTankID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[TFDesCompRefID] [int] NULL,
[TFCompDefID] [int] NULL,
[GroupNum] [decimal] (18, 4) NULL,
[sortindex] [decimal] (18, 4) NULL,
[PortionNum] [int] NULL,
[PortionDescrip] [varchar] (1000) NULL,
[ItemNum] [int] NULL,
[Descrip] [varchar] (1000) NULL,
[Thk] [decimal] (18, 4) NULL,
[Width] [decimal] (18, 4) NULL,
[Length] [decimal] (18, 4) NULL,
[Drg] [varchar] (1000) NULL,
[Spec] [varchar] (1000) NULL,
[Qty] [int] NULL,
[Material] [varchar] (50) NULL,
[Remark] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesBOMTank] on [dbo].[TFDesBOMTank]'
GO
ALTER TABLE [dbo].[TFDesBOMTank] ADD CONSTRAINT [PK_TFDesBOMTank] PRIMARY KEY CLUSTERED  ([TFDesBOMTankID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListTFBOMTank]'
GO







CREATE function [dbo].[desListTFBOMTank]()
returns table
	return (

select tfdesbomtankid,tfdesbomtank.pidunitid,
PortionNum,
sortindex,Thk,Width,[Length],Drg,
PortionDescrip,Itemnum,Descrip,Qty,Spec,Material,tfdesbomtank.Remark

from tfdesbomtank



)






















































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CtlMtgItem]'
GO
CREATE TABLE [dbo].[CtlMtgItem]
(
[CtlMtgItemID] [int] NOT NULL IDENTITY(1, 1),
[CtlMtgID] [int] NULL,
[ItemID] [int] NULL,
[Qty] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CtlMtgItem] on [dbo].[CtlMtgItem]'
GO
ALTER TABLE [dbo].[CtlMtgItem] ADD CONSTRAINT [PK_CtlMtgItem] PRIMARY KEY CLUSTERED  ([CtlMtgItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtlBusTerm]'
GO
CREATE TABLE [dbo].[PIDCtlBusTerm]
(
[PIDCtlBusTermID] [int] NOT NULL IDENTITY(1, 1),
[PIDCtlBusID] [int] NULL,
[PanelCode] [varchar] (50) NULL,
[PIDCtlTermID] [int] NULL,
[LugItemID] [int] NULL,
[LugQty] [int] NULL,
[LugHoleDia] [decimal] (18, 4) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtlBusTerm] on [dbo].[PIDCtlBusTerm]'
GO
ALTER TABLE [dbo].[PIDCtlBusTerm] ADD CONSTRAINT [PK_PIDCtlBusTerm] PRIMARY KEY CLUSTERED  ([PIDCtlBusTermID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtlItem]'
GO
CREATE TABLE [dbo].[PIDCtlItem]
(
[PIDCtlItemID] [int] NOT NULL IDENTITY(1, 1),
[PIDCtlID] [int] NULL,
[ItemID] [int] NULL,
[ItemText] [varchar] (50) NULL,
[Qty] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtlItem] on [dbo].[PIDCtlItem]'
GO
ALTER TABLE [dbo].[PIDCtlItem] ADD CONSTRAINT [PK_PIDCtlItem] PRIMARY KEY CLUSTERED  ([PIDCtlItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDefActPack]'
GO
CREATE TABLE [dbo].[TFCompDefActPack]
(
[TFCompDefActPackID] [int] NOT NULL IDENTITY(1, 1),
[TFCompDefID] [int] NULL,
[ParentActPackID] [int] NULL,
[EvalCondition] [varchar] (8000) NULL,
[Descrip] [varchar] (1000) NULL,
[ContOnError] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefActPack] on [dbo].[TFCompDefActPack]'
GO
ALTER TABLE [dbo].[TFCompDefActPack] ADD CONSTRAINT [PK_TFCompDefActPack] PRIMARY KEY CLUSTERED  ([TFCompDefActPackID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDef]'
GO
CREATE TABLE [dbo].[TFCompDef]
(
[TFCompDefID] [int] NOT NULL IDENTITY(1, 1),
[CompDefCode] [varchar] (50) NULL,
[Descrip] [varchar] (8000) NULL,
[DTBased] [int] NULL,
[DesTableID] [int] NULL,
[DesTableCode] [varchar] (50) NULL,
[DTLocalParamCode] [varchar] (50) NULL,
[DTSelColCode] [varchar] (50) NULL,
[DTDispColKeys] [varchar] (1000) NULL,
[CompFileName] [varchar] (8000) NULL,
[CreateNewASM] [bit] NULL,
[TreatLib] [bit] NULL,
[ParamBehave] [int] NULL,
[Comp2D] [int] NULL,
[BlockName] [varchar] (50) NULL,
[IntDesignCode] [int] NULL,
[DefGroup] [varchar] (1000) NULL,
[ViewName] [varchar] (1000) NULL,
[RemoveConstraints] [bit] NULL,
[LastUpdated] [datetime] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefID] on [dbo].[TFCompDef]'
GO
ALTER TABLE [dbo].[TFCompDef] ADD CONSTRAINT [PK_TFCompDefID] PRIMARY KEY CLUSTERED  ([TFCompDefID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_TFCompDef_1] on [dbo].[TFCompDef]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_TFCompDef_1] ON [dbo].[TFCompDef] ([CompDefCode])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFDesBOMGA]'
GO
CREATE TABLE [dbo].[TFDesBOMGA]
(
[TFDesBOMGAID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[Col1] [int] NULL,
[Col2] [int] NULL,
[MMB] [int] NULL,
[InMM] [bit] NULL,
[InGA] [bit] NULL,
[RNDM] [int] NULL,
[NumItems] [int] NULL,
[pDefCode1] [varchar] (50) NULL,
[pQty1] [int] NULL,
[pDefCode2] [varchar] (50) NULL,
[pQty2] [int] NULL,
[pDefCode3] [varchar] (50) NULL,
[pQty3] [int] NULL,
[pDefCode4] [varchar] (50) NULL,
[pQty4] [int] NULL,
[DefCode] [varchar] (50) NULL,
[NameChart] [varchar] (1000) NULL,
[sortIndex] [int] NULL,
[IsManual] [bit] NULL,
[PipeLine] [varchar] (50) NULL,
[ItemNumSt] [int] NULL,
[ItemNumEnd] [int] NULL,
[ItemNum] [varchar] (50) NULL,
[ItemNumMan] [varchar] (50) NULL,
[Description] [varchar] (1000) NULL,
[Spec] [varchar] (1000) NULL,
[Make] [varchar] (1000) NULL,
[Qty] [int] NULL,
[UnitName] [varchar] (50) NULL,
[Detached] [bit] NULL,
[CaseNumLevel] [int] NULL,
[BaseCodeStd] [varchar] (1000) NULL,
[BaseCodeWO] [varchar] (1000) NULL,
[BaseCode] AS (case when len(rtrim(ltrim([basecodewo])))>(0) then [basecodewo] else [basecodestd] end),
[BasePrm1Code] [varchar] (1000) NULL,
[BasePrm1Value] [varchar] (1000) NULL,
[BasePrm2Code] [varchar] (1000) NULL,
[BasePrm2Value] [varchar] (1000) NULL,
[BasePrm3Code] [varchar] (1000) NULL,
[BasePrm3Value] [varchar] (1000) NULL,
[BasePrm4Code] [varchar] (1000) NULL,
[BasePrm4Value] [varchar] (1000) NULL,
[IsPhantom] [bit] NULL,
[SplitType] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesBOMGA] on [dbo].[TFDesBOMGA]'
GO
ALTER TABLE [dbo].[TFDesBOMGA] ADD CONSTRAINT [PK_TFDesBOMGA] PRIMARY KEY CLUSTERED  ([TFDesBOMGAID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListTFBOMGA]'
GO







CREATE function [dbo].[desListTFBOMGA]()
returns table
	return (

select tfdesbomgaid,tfdesbomga.pidunitid,
namechart,BaseCodeStd,BaseCodeWO,
Defcode,BaseCode,

sortindex,
ItemNum,
[Description],Make,Qty,UnitName ,Detached

from tfdesbomga
where isnull(col1,0)>0

)
























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemUnits]'
GO
CREATE TABLE [dbo].[ItemUnits]
(
[ItemUnitID] [int] NOT NULL IDENTITY(1, 1),
[NameSingular] [varchar] (50) NOT NULL,
[NamePlural] [varchar] (50) NULL,
[UnitName] AS ([nameplural])
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ItemUnits] on [dbo].[ItemUnits]'
GO
ALTER TABLE [dbo].[ItemUnits] ADD CONSTRAINT [PK_ItemUnits] PRIMARY KEY CLUSTERED  ([ItemUnitID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemSubCats]'
GO
CREATE TABLE [dbo].[ItemSubCats]
(
[SubCatName] [nvarchar] (255) NULL,
[SubCatID] [int] NOT NULL IDENTITY(1, 1),
[InitialCode] [nvarchar] (50) NULL,
[ItemSchedID] [int] NULL,
[InvCATID] [int] NULL,
[ItemUnitID] [int] NULL,
[KeepTrack] [bit] NULL,
[RMCONMNTCAP] [int] NULL,
[VendorListHead] [varchar] (1000) NULL,
[strMaint] AS (case isnull([rmconmntcap],(0)) when (1) then 'R.M.' when (2) then 'Consumable' when (3) then 'Maint' when (4) then 'Capital Good' else 'N.D.' end),
[xName] [nvarchar] (100) NULL,
[yName] [nvarchar] (100) NULL,
[zName] [nvarchar] (100) NULL,
[sName] [nvarchar] (100) NULL,
[HasDefs] [bit] NULL,
[tempunitid] [int] NULL,
[pName] [varchar] (100) NULL,
[OldSCName] [varchar] (1000) NULL,
[Example] [varchar] (8000) NULL,
[CodePic] [image] NULL,
[NumGroups] [int] NULL,
[xNameCost] [varchar] (50) NULL,
[yNameCost] [varchar] (50) NULL,
[zNameCost] [varchar] (50) NULL,
[sNameCost] [varchar] (50) NULL,
[pNameCost] [varchar] (50) NULL,
[HasDefsCost] [bit] NULL,
[Remark] [varchar] (1000) NULL,
[ShortName] [varchar] (1000) NULL,
[IsWOSpecific] [bit] NULL,
[IsMacMaint] [bit] NULL,
[IsStock] [bit] NULL,
[ClassABC] [varchar] (1) NULL,
[ClassSDE] [varchar] (1) NULL,
[SelectVMSType] [int] NULL,
[CostingType] [int] NULL,
[CostingItemID] [int] NULL,
[AutoChkItemCode] [bit] NULL,
[ItemnameTemplate] [varchar] (1000) NULL,
[InTankDrawings] [bit] NULL,
[DrgBOMName] [varchar] (1000) NULL,
[BomSectionTypeCode] [int] NULL,
[Density] [decimal] (18, 4) NULL,
[CNCTypeID] [int] NULL,
[pValueA] [int] NULL,
[pValueB] [int] NULL,
[pValueC] [int] NULL,
[pValueD] [int] NULL,
[pValueE] [int] NULL,
[perWastage] [decimal] (18, 2) NULL,
[Dim1Param] [varchar] (50) NULL,
[Dim2Param] [varchar] (50) NULL,
[Dim3Param] [varchar] (50) NULL,
[ParamXMLx] [varchar] (8000) NULL,
[ParamXMLy] [varchar] (8000) NULL,
[ParamXMLz] [varchar] (8000) NULL,
[ParamXMLp] [varchar] (8000) NULL,
[ParamXMLs] [varchar] (8000) NULL,
[CostingPriceFac] [decimal] (18, 4) NULL,
[CodeFormula] [varchar] (1000) NULL,
[NameFormula] [varchar] (1000) NULL,
[vxName] [varchar] (50) NULL,
[vyName] [varchar] (50) NULL,
[MatHeadRemark] [varchar] (1000) NULL,
[CostingItemFormula] [varchar] (1000) NULL,
[CostSummParamIndex] [int] NULL,
[PurchaseSpec] [varchar] (1000) NULL,
[AdvanceMat] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__ItemSubC__396379752BFE89A6] on [dbo].[ItemSubCats]'
GO
ALTER TABLE [dbo].[ItemSubCats] ADD CONSTRAINT [PK__ItemSubC__396379752BFE89A6] PRIMARY KEY CLUSTERED  ([SubCatID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemScheds]'
GO
CREATE TABLE [dbo].[ItemScheds]
(
[ItemSchedID] [int] NOT NULL,
[SchedCode] [varchar] (2) NULL,
[SchedName] [nvarchar] (255) NULL,
[pNameA] [varchar] (100) NULL,
[pXMLA] [varchar] (8000) NULL,
[pNameB] [varchar] (100) NULL,
[pXMLB] [varchar] (8000) NULL,
[pNameC] [varchar] (100) NULL,
[pXMLC] [varchar] (8000) NULL,
[pNameD] [varchar] (100) NULL,
[pXMLD] [varchar] (8000) NULL,
[pNameE] [varchar] (100) NULL,
[pXMLE] [varchar] (8000) NULL,
[HasParams] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ItemSuperCats] on [dbo].[ItemScheds]'
GO
ALTER TABLE [dbo].[ItemScheds] ADD CONSTRAINT [PK_ItemSuperCats] PRIMARY KEY CLUSTERED  ([ItemSchedID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Items]'
GO
CREATE TABLE [dbo].[Items]
(
[ItemID] [int] NOT NULL IDENTITY(1, 1),
[ItemCode] [nvarchar] (50) NULL,
[SubCatID] [int] NULL,
[ItemSizeID] [int] NULL,
[ItemName] [nvarchar] (255) NULL,
[IsCritical] [bit] NULL,
[ShelfLife] [int] NULL,
[MinLevel] [real] NULL,
[WarnLevel] [real] NULL,
[NextIndex] [int] NULL,
[xValue] [decimal] (18, 4) NULL,
[yValue] [decimal] (18, 4) NULL,
[zValue] [decimal] (18, 4) NULL,
[pValue] [decimal] (18, 4) NULL,
[sValue] [varchar] (50) NULL,
[ParamLayoutCols] [smallint] NULL,
[ShortName] [varchar] (50) NULL,
[AcceptWO] [bit] NULL,
[MatSpec] [varchar] (1000) NULL,
[QtyDef] [int] NULL,
[QtyAsReq] [bit] NULL,
[MatListOK] [bit] NULL,
[OldCode] [varchar] (50) NULL,
[OldName] [varchar] (1000) NULL,
[CostingItemID] [int] NULL,
[MinOrderQty] [decimal] (18, 4) NULL,
[Application] [varchar] (1000) NULL,
[BOMThk] [decimal] (18, 4) NULL,
[BOMMatSection] [varchar] (1000) NULL,
[WtPerMtr] [decimal] (18, 4) NULL,
[AreaPerMtr] [decimal] (18, 4) NULL,
[WtPerNo] [decimal] (18, 4) NULL,
[SectionDim1] [decimal] (18, 4) NULL,
[SectionDim2] [decimal] (18, 4) NULL,
[SectionDim3] [decimal] (18, 4) NULL,
[PurchasePrice] [decimal] (18, 4) NULL,
[PurchPriceLastUpd] [datetime] NULL,
[CostingPrice] [decimal] (18, 4) NULL,
[SelectVMSType] [int] NULL,
[CreatedBy] [varchar] (50) NULL,
[CreatedOn] [datetime] NULL,
[LastModBy] [varchar] (50) NULL,
[LastModOn] [datetime] NULL,
[LastModApp] [varchar] (50) NULL,
[BOMNonStd] [bit] NULL,
[DrgBOMName] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__Items__727E83EB2FCF1A8A] on [dbo].[Items]'
GO
ALTER TABLE [dbo].[Items] ADD CONSTRAINT [PK__Items__727E83EB2FCF1A8A] PRIMARY KEY CLUSTERED  ([ItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CNCTypes]'
GO
CREATE TABLE [dbo].[CNCTypes]
(
[CNCTypeID] [int] NOT NULL IDENTITY(1, 1),
[CNCTypeName] [varchar] (1000) NULL,
[IsGasket] [bit] NULL,
[InItemCollec] [bit] NULL,
[IsHardware] [bit] NULL,
[TitleQC] [varchar] (8000) NULL,
[WeldedTypeID] [int] NULL,
[BOMSepCharts] AS (case when isnull([isgasket],(0))=(1) OR isnull([ishardware],(0))=(1) then (1) else (0) end),
[InAttachMatList] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__CNCTypes__51291A10] on [dbo].[CNCTypes]'
GO
ALTER TABLE [dbo].[CNCTypes] ADD CONSTRAINT [PK__CNCTypes__51291A10] PRIMARY KEY CLUSTERED  ([CNCTypeID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDUParams]'
GO
CREATE TABLE [dbo].[PIDUParams]
(
[PIDUParamID] [int] NOT NULL IDENTITY(1, 1),
[DesParamID] [int] NULL,
[PIDUnitID] [int] NULL,
[ParamValue] [ntext] NULL,
[ParamTag] [ntext] NULL,
[ValueDescrip] [ntext] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDUParams] on [dbo].[PIDUParams]'
GO
ALTER TABLE [dbo].[PIDUParams] ADD CONSTRAINT [PK_PIDUParams] PRIMARY KEY CLUSTERED  ([PIDUParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesParams]'
GO
CREATE TABLE [dbo].[DesParams]
(
[DesParamID] [int] NOT NULL IDENTITY(1, 1),
[DataType] [int] NULL,
[RIDesTableID] [int] NULL,
[DesTableColID] [int] NULL,
[ParamCode] [varchar] (100) NULL,
[ParamName] [varchar] (1000) NULL,
[ParamGroup] [varchar] (8000) NULL,
[Remark] [varchar] (1000) NULL,
[IsNumber] AS (case when isnull([datatype],(0))>(0) then (1) else (0) end),
[sortindex] [int] NULL,
[DefaultValue] [varchar] (1000) NULL,
[Lastupdated] [datetime] NULL,
[IsDBCADParam] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DesParams] on [dbo].[DesParams]'
GO
ALTER TABLE [dbo].[DesParams] ADD CONSTRAINT [PK_DesParams] PRIMARY KEY CLUSTERED  ([DesParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DesParams] on [dbo].[DesParams]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DesParams] ON [dbo].[DesParams] ([ParamCode])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFDesCompRef]'
GO
CREATE TABLE [dbo].[TFDesCompRef]
(
[TFDesCompRefID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[TFCompDefID] [int] NULL,
[CompDefPath] [varchar] (1000) NULL,
[TFCompDefDetBOMID] [int] NULL,
[BaseFileName] [varchar] (1000) NULL,
[NewFileName] [varchar] (1000) NULL,
[IsOld] [bit] NULL,
[sortindex] [int] NULL,
[Qty] [int] NULL,
[pCompRefID] [int] NULL,
[ErrorCode] [varchar] (50) NULL,
[ErrorDescrip] [varchar] (1000) NULL,
[MD5HashCode] [varchar] (1000) NULL,
[BaseLastModified] [datetime] NULL,
[DeepCopyFiles] [varchar] (8000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesCompRef] on [dbo].[TFDesCompRef]'
GO
ALTER TABLE [dbo].[TFDesCompRef] ADD CONSTRAINT [PK_TFDesCompRef] PRIMARY KEY CLUSTERED  ([TFDesCompRefID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDefDetBOM]'
GO
CREATE TABLE [dbo].[TFCompDefDetBOM]
(
[TFCompDefDetBOMID] [int] NOT NULL IDENTITY(1, 1),
[TFCompDefID] [int] NULL,
[tfcompdefshotid] [int] NULL,
[DescripFormula] [varchar] (8000) NULL,
[ThkFormula] [varchar] (8000) NULL,
[WidthFormula] [varchar] (8000) NULL,
[LengthFormula] [varchar] (8000) NULL,
[DrgFormula] [varchar] (8000) NULL,
[QtyFormula] [varchar] (8000) NULL,
[DesTableRowID] [int] NULL,
[CompFileName] [varchar] (8000) NULL,
[CompDefCodeFormula] [varchar] (8000) NULL,
[ChildCompDefID] [int] NULL,
[NewName] [varchar] (50) NULL,
[Remarks] [varchar] (1000) NULL,
[InheritParams] [bit] NULL,
[InheritActPack] [bit] NULL,
[InHerited] AS (case when isnull([inheritparams],(0))=(1) OR isnull([inheritactpack],(0))=(1) then (1) else (0) end),
[SortIndex] [int] NULL,
[IsBOM] AS (case when [childcompdefid] IS NULL AND isnull([compdefcodeformula],'')='' then (1) else (0) end),
[CreateCopy] [bit] NULL,
[BlockName] [varchar] (1000) NULL,
[GroupNumFormula] [varchar] (1000) NULL,
[PortionNumFormula] [varchar] (1000) NULL,
[MaterialFormula] [varchar] (1000) NULL,
[RemarkFormula] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefDetBOM] on [dbo].[TFCompDefDetBOM]'
GO
ALTER TABLE [dbo].[TFCompDefDetBOM] ADD CONSTRAINT [PK_TFCompDefDetBOM] PRIMARY KEY CLUSTERED  ([TFCompDefDetBOMID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[StdDrg]'
GO
CREATE TABLE [dbo].[StdDrg]
(
[StdDrgID] [int] NOT NULL IDENTITY(1, 1),
[FileStoreID] [int] NULL,
[CompleteNum] AS (((([stdseries]+' ')+[groupnum])+' ')+[drgnum]),
[DrgName] [varchar] (1000) NULL,
[Descrip] [varchar] (1000) NULL,
[RevDueFrom] [datetime] NULL,
[RevDue] [varchar] (1000) NULL,
[ForFile] [varchar] (1000) NULL,
[DesEmpID] [int] NULL,
[StdSeries] [varchar] (2) NULL,
[GroupNum] [varchar] (50) NULL,
[DrgNum] [varchar] (50) NULL,
[BOMMaxNum] [int] NULL,
[IsGhost] [bit] NULL,
[RevNum] [int] NULL,
[RevDate] [datetime] NULL,
[PDFSource] [varchar] (1000) NULL,
[HasCollec] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__StdDrg__E924BA5A0DAF0CB0] on [dbo].[StdDrg]'
GO
ALTER TABLE [dbo].[StdDrg] ADD CONSTRAINT [PK__StdDrg__E924BA5A0DAF0CB0] PRIMARY KEY CLUSTERED  ([StdDrgID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListStdDrg]'
GO





CREATE        function [dbo].[desListStdDrg]()
returns table
	return (


select StdDrgID,
case when revduefrom is null then 1 else 0 end as iscompleted,
StdSeries,DrgNum,GroupNum,

CompleteNum, DrgName, 

Descrip,
RevNum,RevDate,
RevDue, RevDueFrom,   ForFile


from stddrg
	
)















































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFPartDefCat]'
GO
CREATE TABLE [dbo].[TFPartDefCat]
(
[TFPartDefCatID] [int] NOT NULL IDENTITY(1, 1),
[Descrip] [varchar] (1000) NULL,
[TFPartDefClass] [varchar] (50) NULL,
[TFPartDefClassName] [varchar] (50) NULL,
[TFPartDefClassChName] [varchar] (50) NULL,
[Param1Name] [varchar] (50) NULL,
[Param2Name] [varchar] (50) NULL,
[Param3Name] [varchar] (50) NULL,
[Param4Name] [varchar] (50) NULL,
[Param5Name] [varchar] (50) NULL,
[Param6Name] [varchar] (50) NULL,
[Param7Name] [varchar] (50) NULL,
[IgnorePipeLine] AS (case when [tfpartdefclass]='tw' OR [tfpartdefclass]='oring' OR [tfpartdefclass]='gasdrg' OR [tfpartdefclass]='garectlw' OR [tfpartdefclass]='garectlolivarw' OR [tfpartdefclass]='garectlolifixw' OR [tfpartdefclass]='garound' then (1) else (0) end)
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFPartDefCat] on [dbo].[TFPartDefCat]'
GO
ALTER TABLE [dbo].[TFPartDefCat] ADD CONSTRAINT [PK_TFPartDefCat] PRIMARY KEY CLUSTERED  ([TFPartDefCatID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFPartDef]'
GO
CREATE TABLE [dbo].[TFPartDef]
(
[TFPartDefID] [int] NOT NULL IDENTITY(1, 1),
[TFPartDefCatID] [int] NULL,
[TFPartDefCodeCalc] AS (case when isnull([tfpartdefcode],'')='' then 'NOCODE'+CONVERT([varchar],[tfpartdefid],(0)) else [tfpartdefcode] end) PERSISTED,
[TFPartDefCode] [varchar] (50) NULL,
[TypeNum] [int] NULL,
[Param1Value] [varchar] (1000) NULL,
[Param2Value] [varchar] (1000) NULL,
[Param3Value] [varchar] (1000) NULL,
[Param4Value] [varchar] (1000) NULL,
[Param5Value] [varchar] (1000) NULL,
[Param6Value] [varchar] (1000) NULL,
[Param7Value] [varchar] (1000) NULL,
[CSDia] [decimal] (18, 4) NULL,
[InnerDia] [varchar] (50) NULL,
[OuterDia] [varchar] (50) NULL,
[Thk] [decimal] (18, 4) NULL,
[Lo] [decimal] (18, 4) NULL,
[Li] [decimal] (18, 4) NULL,
[Bo] [decimal] (18, 4) NULL,
[Bi] [decimal] (18, 4) NULL,
[Wid] [decimal] (18, 4) NULL,
[L1] [decimal] (18, 4) NULL,
[L2] [decimal] (18, 4) NULL,
[Drg] [varchar] (50) NULL,
[ParamXML] [varchar] (8000) NULL,
[ParamDescrip] [varchar] (1000) NULL,
[DescripFinal] [varchar] (1000) NULL,
[ItemID] [int] NULL,
[Remark] [varchar] (1000) NULL,
[ChartDescrip] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFPartDef] on [dbo].[TFPartDef]'
GO
ALTER TABLE [dbo].[TFPartDef] ADD CONSTRAINT [PK_TFPartDef] PRIMARY KEY CLUSTERED  ([TFPartDefID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_TFPartDef] on [dbo].[TFPartDef]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_TFPartDef] ON [dbo].[TFPartDef] ([TFPartDefCodeCalc])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFAssyDefBOM]'
GO
CREATE TABLE [dbo].[TFAssyDefBOM]
(
[TFAssyDefBOMID] [int] NOT NULL IDENTITY(1, 1),
[TFAssyDefID] [int] NULL,
[Descrip] [varchar] (8000) NULL,
[DescripFormula] [varchar] (8000) NULL,
[DesTableRowID] [int] NULL,
[DefCodeFormula] [varchar] (8000) NULL,
[sParamFormula] [varchar] (8000) NULL,
[ChildAssyDefID] [int] NULL,
[ChildPartDefID] [int] NULL,
[SpecRowDef] [bit] NULL,
[BOMType] [int] NULL,
[Remarks] [varchar] (1000) NULL,
[ChartSuffix] [varchar] (1000) NULL,
[InheritParams] [bit] NULL,
[InHerited] AS (case when isnull([inheritparams],(0))=(1) then (1) else (0) end),
[SortIndex] [int] NULL,
[HWMainElemType] [int] NULL,
[HWDiaFormula] [varchar] (1000) NULL,
[HWLenFormula] [varchar] (1000) NULL,
[PWNum] [int] NULL,
[SWNum] [int] NULL,
[LockNutNum] [int] NULL,
[FullNutNum] [int] NULL,
[TWNum] [int] NULL,
[QtyFormula] [varchar] (8000) NULL,
[QtyFormulaTanking] [varchar] (8000) NULL,
[QtyFormulaTrptIfDet] [varchar] (8000) NULL,
[QtyFormulaTrptIfNoDet] [varchar] (8000) NULL,
[QtyFormulaErection] [varchar] (8000) NULL,
[NewName] [varchar] (1000) NULL,
[ShowCode] [bit] NULL,
[ParentCaseCodeFormula] [varchar] (1000) NULL,
[NumCalc] AS ((((((((case when charindex('[//',[DefCodeFormula])>(0) then (1) else (0) end+case when charindex('[//',[sParamFormula])>(0) then (1) else (0) end)+case when charindex('[//',[HWDiaFormula])>(0) then (1) else (0) end)+case when charindex('[//',[HWLenFormula])>(0) then (1) else (0) end)+case when charindex('[//',[QtyFormula])>(0) then (1) else (0) end)+case when charindex('[//',[QtyFormulaTanking])>(0) then (1) else (0) end)+case when charindex('[//',[QtyFormulaTrptIfDet])>(0) then (1) else (0) end)+case when charindex('[//',[QtyFormulaTrptIfNoDet])>(0) then (1) else (0) end)+case when charindex('[//',[QtyFormulaErection])>(0) then (1) else (0) end),
[IsWeldedHW] [bit] NULL,
[IsInternalHW] [bit] NULL,
[ForceInPackList] [int] NULL,
[PipelineFormula] [varchar] (50) NULL,
[ForceParentCaseIndexFormula] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__TFAssyDefBOM__5A879BC1] on [dbo].[TFAssyDefBOM]'
GO
ALTER TABLE [dbo].[TFAssyDefBOM] ADD CONSTRAINT [PK__TFAssyDefBOM__5A879BC1] PRIMARY KEY CLUSTERED  ([TFAssyDefBOMID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFAssyDef]'
GO
CREATE TABLE [dbo].[TFAssyDef]
(
[TFAssyDefID] [int] NOT NULL IDENTITY(1, 1),
[pTFAssyDefID] [int] NULL,
[PIDUnitID] [int] NULL,
[AssyDefCode] [varchar] (50) NULL,
[Descrip] [varchar] (8000) NULL,
[Remarks] [varchar] (8000) NULL,
[DTBased] [int] NULL,
[DesTableID] [int] NULL,
[DesTableCode] [varchar] (50) NULL,
[DTLocalParamCode] [varchar] (50) NULL,
[DTSelColCode] [varchar] (50) NULL,
[DTDispColKeys] [varchar] (1000) NULL,
[SplitMultQty] [bit] NULL,
[SplitMultQtyMin] [int] NULL,
[SplitMultQtyMax] [int] NULL,
[DetachType] [int] NULL,
[GADescripSuffixFormula] [varchar] (1000) NULL,
[DontAddOrigItem] [bit] NULL,
[CreatedBy] [varchar] (50) NULL,
[CreatedOn] [datetime] NULL,
[LastModBy] [varchar] (50) NULL,
[LastModOn] [datetime] NULL,
[LastModApp] [varchar] (50) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__TFAssyDef__54CEC26B] on [dbo].[TFAssyDef]'
GO
ALTER TABLE [dbo].[TFAssyDef] ADD CONSTRAINT [PK__TFAssyDef__54CEC26B] PRIMARY KEY CLUSTERED  ([TFAssyDefID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_TFAssyDef] on [dbo].[TFAssyDef]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_TFAssyDef] ON [dbo].[TFAssyDef] ([AssyDefCode], [pTFAssyDefID], [PIDUnitID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFDesAssyMat]'
GO
CREATE TABLE [dbo].[TFDesAssyMat]
(
[TFDesAssyMatID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[DefCode] [varchar] (50) NULL,
[ParentCaseCode] [varchar] (50) NULL,
[TFPartDefID] [int] NULL,
[ItemID] [int] NULL,
[HWMainElemType] [int] NULL,
[HWMainElem] [varchar] (50) NULL,
[HWSize] [varchar] (50) NULL,
[HWDia] [decimal] (18, 2) NULL,
[HWLen] [decimal] (18, 2) NULL,
[PWNum] [int] NULL,
[SWNum] [int] NULL,
[LockNutNum] [int] NULL,
[FullNutNum] [int] NULL,
[Descrip] [varchar] (1000) NULL,
[QtyTanking] [int] NULL,
[QtyTransport] [int] NULL,
[QtyErection] [int] NULL,
[IsParent] [bit] NULL,
[sParam] [varchar] (8000) NULL,
[ChartSuffix] [varchar] (1000) NULL,
[IsWeldedHW] [bit] NULL,
[IsInternalHW] [bit] NULL,
[ForceInPackList] [int] NULL,
[PipeLine] [varchar] (50) NULL,
[ForceParentCaseIndex] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesAssyMat] on [dbo].[TFDesAssyMat]'
GO
ALTER TABLE [dbo].[TFDesAssyMat] ADD CONSTRAINT [PK_TFDesAssyMat] PRIMARY KEY CLUSTERED  ([TFDesAssyMatID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFDesPackList]'
GO
CREATE TABLE [dbo].[TFDesPackList]
(
[TFDesPackListID] [int] NOT NULL IDENTITY(1, 1),
[TFDesAssyMatID] [int] NULL,
[CaseNum] [decimal] (18, 4) NULL,
[ItemNum] [decimal] (18, 4) NULL,
[AppendIndent] [varchar] (50) NULL,
[Qty] [int] NULL,
[QtyOp2] [int] NULL,
[PackNote] [varchar] (1000) NULL,
[QtyTanking] [int] NULL,
[QtyTransport] [int] NULL,
[QtyErection] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesPackList] on [dbo].[TFDesPackList]'
GO
ALTER TABLE [dbo].[TFDesPackList] ADD CONSTRAINT [PK_TFDesPackList] PRIMARY KEY CLUSTERED  ([TFDesPackListID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFDesAssyMatItem]'
GO
CREATE TABLE [dbo].[TFDesAssyMatItem]
(
[TFDesAssyMatItemID] [int] NOT NULL IDENTITY(1, 1),
[TFDesAssyMatID] [int] NULL,
[ItemID] [int] NULL,
[Description] [varchar] (50) NULL,
[QtyTanking] [int] NULL,
[QtyTransport] [int] NULL,
[QtyErection] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesAssyMatItem] on [dbo].[TFDesAssyMatItem]'
GO
ALTER TABLE [dbo].[TFDesAssyMatItem] ADD CONSTRAINT [PK_TFDesAssyMatItem] PRIMARY KEY CLUSTERED  ([TFDesAssyMatItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ProDocu]'
GO
CREATE TABLE [dbo].[ProDocu]
(
[ProDocuID] [int] NOT NULL IDENTITY(1, 1),
[DesDocID] [int] NULL,
[PIDUnitID] [int] NULL,
[DocName] [varchar] (1000) NULL,
[Suffix] [varchar] (1000) NULL,
[PreFix] [varchar] (1000) NULL,
[NumSheets] [varchar] (1000) NULL,
[SerialNum] [int] NULL,
[DrgNumGroup] [int] NULL,
[DrgNum] [varchar] (800) NULL,
[RevNum] [varchar] (1000) NULL,
[RevDate] [datetime] NULL,
[RefDrg] [varchar] (1000) NULL,
[Remark] [varchar] (1000) NULL,
[IssuedOn] [datetime] NULL,
[DrgOn] [datetime] NULL,
[ChkOn] [datetime] NULL,
[AppOn] [datetime] NULL,
[PlanOn] [datetime] NULL,
[BlankLineA] [bit] NULL,
[BlankLineB] [bit] NULL,
[HasBOM] [bit] NULL,
[HasCollec] [bit] NULL,
[BOMMaxNum] [int] NULL,
[ReportStatus] [varchar] (1000) NULL,
[ReportRemark] [varchar] (1000) NULL,
[DocEmpID] [int] NULL,
[PrepByID] [int] NULL,
[PrepByID2] [int] NULL,
[ChkByID] [int] NULL,
[AppByID] [int] NULL,
[PDFSource] [varchar] (1000) NULL,
[IDField] [varchar] (1000) NULL,
[IDValue] [int] NULL,
[ActSource] [varchar] (1000) NULL,
[pdfownerpass] [varchar] (1000) NULL,
[pdfuserpass] [varchar] (1000) NULL,
[TopLevelDoc] [bit] NULL,
[StatusGroupNum] [int] NULL,
[DocDistriCodeID] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ProDocu] on [dbo].[ProDocu]'
GO
ALTER TABLE [dbo].[ProDocu] ADD CONSTRAINT [PK_ProDocu] PRIMARY KEY CLUSTERED  ([ProDocuID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_ProDocu] on [dbo].[ProDocu]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_ProDocu] ON [dbo].[ProDocu] ([DesDocID], [PIDUnitID], [DrgNum])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DocDistriCode]'
GO
CREATE TABLE [dbo].[DocDistriCode]
(
[DocDistriCodeID] [int] NOT NULL IDENTITY(1, 1),
[DistriCode] [varchar] (1000) NULL,
[MfgTypeCode] [varchar] (50) NULL,
[DocTypeCode] [varchar] (50) NULL,
[MatDepID] [int] NULL,
[DistriDescrip] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DocDistriCode] on [dbo].[DocDistriCode]'
GO
ALTER TABLE [dbo].[DocDistriCode] ADD CONSTRAINT [PK_DocDistriCode] PRIMARY KEY CLUSTERED  ([DocDistriCodeID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DocDistriCode] on [dbo].[DocDistriCode]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DocDistriCode] ON [dbo].[DocDistriCode] ([DocTypeCode], [MfgTypeCode])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesDocs]'
GO
CREATE TABLE [dbo].[DesDocs]
(
[DesDocID] [int] NOT NULL IDENTITY(1, 1),
[TypeCode] [varchar] (50) NULL,
[WdgName1] [varchar] (50) NULL,
[WdgName2] [varchar] (50) NULL,
[TermNum] [int] NULL,
[UniqueCode] AS (case when isnull([typecode],'')='' then CONVERT([varchar],[desdocid],(0)) else ((([typecode]+'-')+isnull([wdgname1],''))+'-')+isnull(CONVERT([varchar],[termnum],(0)),'') end),
[DocText] [varchar] (1000) NULL,
[DocTextXML] [varchar] (8000) NULL,
[FilterCode] [varchar] (50) NULL,
[FilterParam] [int] NULL,
[FilterParamXML] [varchar] (1000) NULL,
[DesDocGrpID] [int] NULL,
[IsChart] [bit] NULL,
[DisplayOrder] [int] NOT NULL,
[TopLevelBOM] [bit] NULL,
[ConsAutoList] [bit] NULL,
[IndexFormula] [varchar] (1000) NULL,
[GroupInsideOR] [bit] NULL,
[NumSheetsFormula] [varchar] (1000) NULL,
[AutoTypeCode] [int] NULL,
[DisplayForm] [varchar] (1000) NULL,
[GenFunc] [varchar] (1000) NULL,
[ParamCode] [varchar] (50) NULL,
[ParamValue] [varchar] (50) NULL,
[IsCurrent] [bit] NULL,
[OpenedOn] [datetime] NULL,
[RefFile] [varchar] (50) NULL,
[FilePartCode] [int] NULL,
[FilePart] [varchar] (1000) NULL,
[DraftDeskCode] [int] NULL,
[DraftDesk] [varchar] (1000) NULL,
[DistriTypeCode] [varchar] (1000) NULL,
[InAssemblyExt] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DesDocs] on [dbo].[DesDocs]'
GO
ALTER TABLE [dbo].[DesDocs] ADD CONSTRAINT [PK_DesDocs] PRIMARY KEY CLUSTERED  ([DesDocID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DesDocs] on [dbo].[DesDocs]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DesDocs] ON [dbo].[DesDocs] ([UniqueCode])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DesDocs_1] on [dbo].[DesDocs]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DesDocs_1] ON [dbo].[DesDocs] ([DisplayOrder], [DesDocGrpID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesDocGrp]'
GO
CREATE TABLE [dbo].[DesDocGrp]
(
[DesDocGrpID] [int] NOT NULL IDENTITY(1, 1),
[DesDocGrp] [varchar] (1000) NULL,
[IsForNesting] [bit] NULL,
[InAssemblyExt] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__DesDocType__40B12477] on [dbo].[DesDocGrp]'
GO
ALTER TABLE [dbo].[DesDocGrp] ADD CONSTRAINT [PK__DesDocType__40B12477] PRIMARY KEY CLUSTERED  ([DesDocGrpID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fncStringNum]'
GO











CREATE  function [dbo].[fncStringNum](@itemnum varchar(1000), @maxnumber int)
returns varchar(1000)
begin
	declare @tempname varchar(1000)
	
set @tempname=
	case when @maxnumber>99 then
		case when len(@itemnum)=1 then '00'
		when len(@itemnum)=2 then '0'
		else '' end 
	when @maxnumber>9 then
		case when len(@itemnum)=1 then '0'
		else '' end 
	else  '' end +@itemnum 


	return @tempname
end















GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fncMax]'
GO












CREATE  function [dbo].[fncMax](@val1 decimal(18,4),@val2 decimal(18,4))
returns decimal(18,4)
begin
	declare @val decimal(18,4)
	set @val=case when @val1>@val2 then @val1 else @val2 end
	return @val
end


















GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fncGetHWType]'
GO




CREATE     FUNCTION [dbo].[fncGetHWType](@HWTypeXML varchar(max),@elementcode int)
RETURNS varchar(1000)
AS  
BEGIN 
	declare @doc xml
	declare @element varchar(1000)

	set @doc = convert(xml,'<ROOT>'+@hwtypexml+'</ROOT>')

	if isnull(@hwtypexml,'')<>'' begin
		select top 1 @element=myxml.val.value('./@TEXT','varchar(1000)')
		from @doc.nodes('/ROOT/VALUE') myxml(val) where myxml.val.value('./@VALUE1','int')=@elementcode
	end

	return @element
END



GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DrgItems]'
GO
CREATE TABLE [dbo].[DrgItems]
(
[DrgItemID] [int] NOT NULL IDENTITY(1, 1),
[StdDrgID] [int] NULL,
[ProDocuID] [int] NULL,
[ItemID] [int] NULL,
[IsCollection] [bit] NULL,
[IsBoughtOut] [bit] NULL,
[IsDeleted] [bit] NULL,
[ItemCollecTypeCode] [int] NULL,
[RefDrgItemID] [int] NULL,
[ItemNum] [varchar] (50) NULL,
[ItemNum1] [int] NULL,
[ItemNum2] [varchar] (50) NULL,
[Description] [varchar] (1000) NULL,
[DescripChart] [varchar] (1000) NULL,
[DescripChartAddl] [varchar] (1000) NULL,
[MatSection] [varchar] (1000) NULL,
[Thk] [decimal] (18, 2) NULL,
[Length] [varchar] (50) NULL,
[Width] [varchar] (50) NULL,
[Length2] [varchar] (50) NULL,
[Width2] [varchar] (50) NULL,
[InnerDia] [varchar] (50) NULL,
[OuterDia] [varchar] (50) NULL,
[Material] [varchar] (1000) NULL,
[Specification] [varchar] (1000) NULL,
[AddlSpec] [varchar] (1000) NULL,
[Qty] [decimal] (18, 2) NULL,
[Remark] [varchar] (1000) NULL,
[Weight] [decimal] (18, 4) NULL,
[CNCDrg] [varchar] (1000) NULL,
[Category] [varchar] (1000) NULL,
[SubCategory] [varchar] (1000) NULL,
[RectReduceXML] [varchar] (8000) NULL,
[RoundReduceXML] [varchar] (8000) NULL,
[TriangleReduceXML] [varchar] (8000) NULL,
[RadiusReduceXML] [varchar] (8000) NULL,
[TotalArea] [decimal] (18, 4) NULL,
[SeeDetail] [bit] NULL,
[IsManualWt] [bit] NULL,
[GasketTypeCode] [int] NULL,
[ThkParamID] [int] NULL,
[LengthParamID] [int] NULL,
[WidthParamID] [int] NULL,
[Length2ParamID] [int] NULL,
[Width2ParamID] [int] NULL,
[InnerDiaParamID] [int] NULL,
[OuterDiaParamID] [int] NULL,
[ThreadParamID] [int] NULL,
[ParamReqXML] [varchar] (8000) NULL,
[ParamValueXML] [varchar] (8000) NULL,
[HasNoJoints] [bit] NULL,
[HasLegend] [bit] NULL,
[CNCDrg2] [varchar] (1000) NULL,
[CNCDrg3] [varchar] (1000) NULL,
[CNCDrg4] [varchar] (1000) NULL,
[NoCommonCut] [bit] NULL,
[IsWelded] [bit] NULL,
[ShowNonStd] [bit] NULL,
[ExcludeCNC] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CNCDrg] on [dbo].[DrgItems]'
GO
ALTER TABLE [dbo].[DrgItems] ADD CONSTRAINT [PK_CNCDrg] PRIMARY KEY CLUSTERED  ([DrgItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItems_4] on [dbo].[DrgItems]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItems_4] ON [dbo].[DrgItems] ([StdDrgID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItems] on [dbo].[DrgItems]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DrgItems] ON [dbo].[DrgItems] ([StdDrgID], [ProDocuID], [ItemNum])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItems_1] on [dbo].[DrgItems]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItems_1] ON [dbo].[DrgItems] ([ProDocuID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItems_2] on [dbo].[DrgItems]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItems_2] ON [dbo].[DrgItems] ([ItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItems_3] on [dbo].[DrgItems]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItems_3] ON [dbo].[DrgItems] ([RefDrgItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DrgItemCalc]'
GO
CREATE TABLE [dbo].[DrgItemCalc]
(
[DrgItemCalcID] [int] NOT NULL IDENTITY(1, 1),
[DrgItemID] [int] NULL,
[ChildDrgItemID] [int] NULL,
[ItemID] [int] NULL,
[Qty] [decimal] (18, 2) NULL,
[Legend] [varchar] (50) NULL,
[Reference] [varchar] (1000) NULL,
[RefIDList] [varchar] (1000) NULL,
[Thk] [decimal] (18, 4) NULL,
[Length] [decimal] (18, 4) NULL,
[Width] [decimal] (18, 4) NULL,
[InnerDia] [decimal] (18, 4) NULL,
[OuterDia] [decimal] (18, 4) NULL,
[Length2] [decimal] (18, 4) NULL,
[Width2] [decimal] (18, 4) NULL,
[Thread] [decimal] (18, 4) NULL,
[AreaReduce] [decimal] (18, 4) NULL,
[Weight] [decimal] (18, 4) NULL,
[Description] [varchar] (1000) NULL,
[DescripChart] [varchar] (1000) NULL,
[Specification] [varchar] (1000) NULL,
[CNCDrgNew] [varchar] (1000) NULL,
[CNCDrgNew2] [varchar] (8000) NULL,
[CNCDrgNew3] [varchar] (8000) NULL,
[CNCDrgNew4] [varchar] (8000) NULL,
[CNCTypeIDNew] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__DrgItemCalc__53116282] on [dbo].[DrgItemCalc]'
GO
ALTER TABLE [dbo].[DrgItemCalc] ADD CONSTRAINT [PK__DrgItemCalc__53116282] PRIMARY KEY CLUSTERED  ([DrgItemCalcID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItemCalc] on [dbo].[DrgItemCalc]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItemCalc] ON [dbo].[DrgItemCalc] ([DrgItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItemCalc_2] on [dbo].[DrgItemCalc]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItemCalc_2] ON [dbo].[DrgItemCalc] ([ChildDrgItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItemCalc_1] on [dbo].[DrgItemCalc]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItemCalc_1] ON [dbo].[DrgItemCalc] ([ItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFNestReq]'
GO
CREATE TABLE [dbo].[TFNestReq]
(
[TFNestReqID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[DesDocGrp] [varchar] (1000) NULL,
[DrgItemID] [int] NULL,
[ReqDate] [datetime] NULL,
[WorkGroup] [varchar] (1000) NULL,
[Remark] [varchar] (1000) NULL,
[IsCompleted] [bit] NULL,
[Qty] [int] NULL,
[CNCTypeID] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__TFNestRe__1D52F0BA300424B4] on [dbo].[TFNestReq]'
GO
ALTER TABLE [dbo].[TFNestReq] ADD CONSTRAINT [PK__TFNestRe__1D52F0BA300424B4] PRIMARY KEY CLUSTERED  ([TFNestReqID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DrgItemBOM]'
GO
CREATE TABLE [dbo].[DrgItemBOM]
(
[DrgItemBOMID] [int] NOT NULL IDENTITY(1, 1),
[DrgItemID] [int] NULL,
[ChildDrgItemID] [int] NULL,
[ItemID] [int] NULL,
[Qty] [decimal] (18, 2) NULL,
[Legend] [varchar] (50) NULL,
[Reference] [varchar] (1000) NULL,
[CNCDrg] [varchar] (1000) NULL,
[QtyParamID] [int] NULL,
[CNCDrg2] [varchar] (8000) NULL,
[CNCDrg3] [varchar] (8000) NULL,
[CNCDrg4] [varchar] (8000) NULL,
[DescripBOM] [varchar] (1000) NULL,
[SpecBOM] [varchar] (1000) NULL,
[Weight] [decimal] (18, 4) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DrgItemBOM] on [dbo].[DrgItemBOM]'
GO
ALTER TABLE [dbo].[DrgItemBOM] ADD CONSTRAINT [PK_DrgItemBOM] PRIMARY KEY CLUSTERED  ([DrgItemBOMID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItemBOM] on [dbo].[DrgItemBOM]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItemBOM] ON [dbo].[DrgItemBOM] ([DrgItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItemBOM_1] on [dbo].[DrgItemBOM]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItemBOM_1] ON [dbo].[DrgItemBOM] ([ChildDrgItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItemBOM_2] on [dbo].[DrgItemBOM]'
GO
CREATE NONCLUSTERED INDEX [IX_DrgItemBOM_2] ON [dbo].[DrgItemBOM] ([ItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFNestItems]'
GO
CREATE TABLE [dbo].[TFNestItems]
(
[TFNestItemID] [int] NOT NULL IDENTITY(1, 1),
[TFNestID] [int] NULL,
[TFNestReqID] [int] NULL,
[SNum] [decimal] (18, 4) NULL,
[CNCDrg] [varchar] (1000) NULL,
[PartNum] [varchar] (100) NULL,
[Reference] [varchar] (8000) NULL,
[Description] [varchar] (1000) NULL,
[Specification] [varchar] (8000) NULL,
[QtyReq] [int] NULL,
[Qty] [int] NULL,
[QtyNested] [int] NULL,
[NoCommonCut] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFNestReqItems] on [dbo].[TFNestItems]'
GO
ALTER TABLE [dbo].[TFNestItems] ADD CONSTRAINT [PK_TFNestReqItems] PRIMARY KEY CLUSTERED  ([TFNestItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_TFNestReqItems] on [dbo].[TFNestItems]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_TFNestReqItems] ON [dbo].[TFNestItems] ([TFNestReqID], [SNum], [TFNestID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFNest]'
GO
CREATE TABLE [dbo].[TFNest]
(
[TFNestID] [int] NOT NULL IDENTITY(1, 1),
[CNCTypeID] [int] NULL,
[Thk] [decimal] (18, 2) NULL,
[NestNum] [int] NULL,
[NestNumFab] [int] NULL,
[RevNum] [int] NULL,
[RevDate] [datetime] NULL,
[Remark] [varchar] (1000) NULL,
[CutterDia] [decimal] (18, 2) NULL,
[SUmmary] [varchar] (1000) NULL,
[SheetWidth] [decimal] (18, 2) NULL,
[SheetLength] [decimal] (18, 2) NULL,
[SheetQty] [int] NULL,
[IsNested] [bit] NULL,
[SheetBOMXML] [text] NULL,
[Dated] [datetime] NULL,
[SheetWidth2] [decimal] (18, 4) NULL,
[SheetLength2] [decimal] (18, 4) NULL,
[SheetQty2] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFNest] on [dbo].[TFNest]'
GO
ALTER TABLE [dbo].[TFNest] ADD CONSTRAINT [PK_TFNest] PRIMARY KEY CLUSTERED  ([TFNestID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_TFNest] on [dbo].[TFNest]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_TFNest] ON [dbo].[TFNest] ([NestNum])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[Employees]'
GO
CREATE TABLE [dbo].[Employees]
(
[EmployeeID] [int] NOT NULL,
[Fullname] [varchar] (1000) NULL,
[OnRolls] [bit] NULL,
[LoginName] [varchar] (100) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_Employee] on [dbo].[Employees]'
GO
ALTER TABLE [dbo].[Employees] ADD CONSTRAINT [PK_Employee] PRIMARY KEY CLUSTERED  ([EmployeeID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListEmp]'
GO







CREATE      FUNCTION [dbo].[desListEmp]()
RETURNS TABLE
AS
RETURN ( SELECT     EmployeeID, fullName, 'emp' as entityname,
	employeeid as entityid,onrolls,
fullName as Name,
	 
LoginName AS [Login Name]
FROM    Employees


)







GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListDesDocs]'
GO
















CREATE    function [dbo].[desListDesDocs]()
returns table
	return (


select desdocid,desdocs.desdocgrpid,desdocs.iscurrent,


DocText, 

convert(varchar,desdocgrp.desdocgrpid) + ' - ' + DesDocGrp as DocGroup, IsChart, DisplayOrder, 
FilterCode, FilterParam, FilterParamXML, DocTextXML


from desdocs
	inner join desdocgrp on desdocs.desdocgrpid = desdocgrp.desdocgrpid



)



























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CtlTerminalSet]'
GO
CREATE TABLE [dbo].[CtlTerminalSet]
(
[CtlTerminalSetID] [int] NOT NULL IDENTITY(1, 1),
[Descrip] [varchar] (50) NULL,
[SetPic] [image] NULL,
[SetBlockDrg] [varchar] (1000) NULL,
[NumTerm] [int] NULL,
[SetTypeCode] [int] NULL,
[ImageSF] [decimal] (18, 4) NULL,
[NoWhiteSpace] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_Table_1] on [dbo].[CtlTerminalSet]'
GO
ALTER TABLE [dbo].[CtlTerminalSet] ADD CONSTRAINT [PK_Table_1] PRIMARY KEY CLUSTERED  ([CtlTerminalSetID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CtlTerminal]'
GO
CREATE TABLE [dbo].[CtlTerminal]
(
[CtlTerminalID] [int] NOT NULL IDENTITY(1, 1),
[CtlTerminalSetID] [int] NULL,
[TerminalName] [varchar] (50) NULL,
[TerminalLocX] [int] NULL,
[TerminalLocY] [int] NULL,
[WireLocX] [int] NULL,
[WireLocY] [int] NULL,
[TextAlign] [int] NULL,
[TerminalWIdth] [int] NULL,
[WireWidth] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CtlTerminal] on [dbo].[CtlTerminal]'
GO
ALTER TABLE [dbo].[CtlTerminal] ADD CONSTRAINT [PK_CtlTerminal] PRIMARY KEY CLUSTERED  ([CtlTerminalID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesChkPoint]'
GO
CREATE TABLE [dbo].[DesChkPoint]
(
[DesChkPointID] [int] NOT NULL IDENTITY(1, 1),
[Dated] [datetime] NULL,
[Summary] [varchar] (1000) NULL,
[ContentXML] [text] NULL,
[PDFSource] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DesChkPoint] on [dbo].[DesChkPoint]'
GO
ALTER TABLE [dbo].[DesChkPoint] ADD CONSTRAINT [PK_DesChkPoint] PRIMARY KEY CLUSTERED  ([DesChkPointID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesCPGroupCP]'
GO
CREATE TABLE [dbo].[DesCPGroupCP]
(
[DesCPGroupCPID] [int] NOT NULL IDENTITY(1, 1),
[DesChkPointID] [int] NULL,
[DesCPGroupID] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DesCPGroupCP] on [dbo].[DesCPGroupCP]'
GO
ALTER TABLE [dbo].[DesCPGroupCP] ADD CONSTRAINT [PK_DesCPGroupCP] PRIMARY KEY CLUSTERED  ([DesCPGroupCPID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesCPGroup]'
GO
CREATE TABLE [dbo].[DesCPGroup]
(
[DesCPGroupID] [int] NOT NULL IDENTITY(1, 1),
[GroupName] [varchar] (1000) NULL,
[GroupCode] [varchar] (50) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DesCPGroup] on [dbo].[DesCPGroup]'
GO
ALTER TABLE [dbo].[DesCPGroup] ADD CONSTRAINT [PK_DesCPGroup] PRIMARY KEY CLUSTERED  ([DesCPGroupID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesDocCust]'
GO
CREATE TABLE [dbo].[DesDocCust]
(
[DesDocCustID] [int] NOT NULL IDENTITY(1, 1),
[DesDocID] [int] NOT NULL,
[DocName] [varchar] (1000) NULL,
[CustCode] [varchar] (50) NOT NULL,
[NumSheets] [int] NULL,
[ForTE] [bit] NULL,
[ForOrder] [bit] NULL,
[DocText] [varchar] (100) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DesDocCust] on [dbo].[DesDocCust]'
GO
ALTER TABLE [dbo].[DesDocCust] ADD CONSTRAINT [PK_DesDocCust] PRIMARY KEY CLUSTERED  ([DesDocCustID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DesDocCust] on [dbo].[DesDocCust]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DesDocCust] ON [dbo].[DesDocCust] ([CustCode], [DesDocID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesDocGen]'
GO
CREATE TABLE [dbo].[DesDocGen]
(
[DesDocGenID] [int] NOT NULL IDENTITY(1, 1),
[DesDocID] [int] NULL,
[DesDocTempID] [int] NULL,
[SelectFormula] [varchar] (1000) NULL,
[RangeXML] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DesDocGen] on [dbo].[DesDocGen]'
GO
ALTER TABLE [dbo].[DesDocGen] ADD CONSTRAINT [PK_DesDocGen] PRIMARY KEY CLUSTERED  ([DesDocGenID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesDocTemp]'
GO
CREATE TABLE [dbo].[DesDocTemp]
(
[DesDocTempID] [int] NOT NULL IDENTITY(1, 1),
[DocTempCode] [varchar] (50) NULL,
[DocTempName] [varchar] (1000) NULL,
[fileSource] [varchar] (1000) NULL,
[FileType] [int] NULL,
[sqlXML] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DesDocTemp] on [dbo].[DesDocTemp]'
GO
ALTER TABLE [dbo].[DesDocTemp] ADD CONSTRAINT [PK_DesDocTemp] PRIMARY KEY CLUSTERED  ([DesDocTempID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesDocParam]'
GO
CREATE TABLE [dbo].[DesDocParam]
(
[DesDocParamID] [int] NOT NULL IDENTITY(1, 1),
[DesDocID] [int] NULL,
[DesParamID] [int] NULL,
[DesTableColID] [int] NULL,
[ParamValueEq] [varchar] (1000) NULL,
[MinValue] [decimal] (18, 4) NULL,
[MaxValue] [decimal] (18, 4) NULL,
[ParamValueNEq] [varchar] (1000) NULL,
[EvalGroup] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__DesDocParam__2A0DB641] on [dbo].[DesDocParam]'
GO
ALTER TABLE [dbo].[DesDocParam] ADD CONSTRAINT [PK__DesDocParam__2A0DB641] PRIMARY KEY CLUSTERED  ([DesDocParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesTableRows]'
GO
CREATE TABLE [dbo].[DesTableRows]
(
[DesTableRowID] [int] NOT NULL IDENTITY(1, 1),
[DesTableID] [int] NULL,
[RowIndex] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DesTableRows] on [dbo].[DesTableRows]'
GO
ALTER TABLE [dbo].[DesTableRows] ADD CONSTRAINT [PK_DesTableRows] PRIMARY KEY CLUSTERED  ([DesTableRowID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DesTableRows] on [dbo].[DesTableRows]'
GO
CREATE NONCLUSTERED INDEX [IX_DesTableRows] ON [dbo].[DesTableRows] ([DesTableID], [RowIndex])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesTableData]'
GO
CREATE TABLE [dbo].[DesTableData]
(
[DesTableDataID] [int] NOT NULL IDENTITY(1, 1),
[DesTableColID] [int] NULL,
[DesTableRowID] [int] NULL,
[Data] [nvarchar] (1000) NULL,
[Formula] [varchar] (8000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesData] on [dbo].[DesTableData]'
GO
ALTER TABLE [dbo].[DesTableData] ADD CONSTRAINT [PK_TFDesData] PRIMARY KEY CLUSTERED  ([DesTableDataID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesTables]'
GO
CREATE TABLE [dbo].[DesTables]
(
[DesTableID] [int] NOT NULL IDENTITY(1, 1),
[TableCode] [varchar] (50) NULL,
[TableName] [varchar] (1000) NULL,
[LastRowIndex] [int] NULL,
[InvertedView] [bit] NULL,
[HeadFactor] [int] NULL,
[RHFactor] [int] NULL,
[Lastupdated] [datetime] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesTable] on [dbo].[DesTables]'
GO
ALTER TABLE [dbo].[DesTables] ADD CONSTRAINT [PK_TFDesTable] PRIMARY KEY CLUSTERED  ([DesTableID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DesTables] on [dbo].[DesTables]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DesTables] ON [dbo].[DesTables] ([TableCode])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesTabParam]'
GO
CREATE TABLE [dbo].[DesTabParam]
(
[DesTabParamID] [int] NOT NULL IDENTITY(1, 1),
[CellFormula] [bit] NULL,
[DesTableID] [int] NULL,
[DesParamID] [int] NULL,
[SampleValue] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesTabParam] on [dbo].[DesTabParam]'
GO
ALTER TABLE [dbo].[DesTabParam] ADD CONSTRAINT [PK_TFDesTabParam] PRIMARY KEY CLUSTERED  ([DesTabParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DocDistriCodeDep]'
GO
CREATE TABLE [dbo].[DocDistriCodeDep]
(
[DocDistriCodeDepID] [int] NOT NULL IDENTITY(1, 1),
[DocDistriCodeID] [int] NULL,
[MatDepID] [int] NULL,
[NumCopies] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DosDistriCodeDep] on [dbo].[DocDistriCodeDep]'
GO
ALTER TABLE [dbo].[DocDistriCodeDep] ADD CONSTRAINT [PK_DosDistriCodeDep] PRIMARY KEY CLUSTERED  ([DocDistriCodeDepID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DrgItemParam]'
GO
CREATE TABLE [dbo].[DrgItemParam]
(
[DrgItemParamID] [int] NOT NULL IDENTITY(1, 1),
[DrgItemID] [int] NULL,
[StdDrgParamID] [int] NULL,
[IsUser] [bit] NULL,
[ParamValue] [decimal] (18, 4) NULL,
[StdDrgParamID2] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DrgItemParam] on [dbo].[DrgItemParam]'
GO
ALTER TABLE [dbo].[DrgItemParam] ADD CONSTRAINT [PK_DrgItemParam] PRIMARY KEY CLUSTERED  ([DrgItemParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DrgItemParam] on [dbo].[DrgItemParam]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DrgItemParam] ON [dbo].[DrgItemParam] ([DrgItemID], [StdDrgParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[FileStore]'
GO
CREATE TABLE [dbo].[FileStore]
(
[FileStoreID] [int] NOT NULL IDENTITY(1, 1),
[StoreCode] [varchar] (50) NULL,
[Description] [varchar] (100) NULL,
[UNCPath] [varchar] (2000) NULL,
[Username] [varchar] (2000) NULL,
[Password] [varchar] (2000) NULL,
[IndexServerName] [varchar] (2000) NULL,
[IndexServerCatalog] [varchar] (2000) NULL,
[IndexServerUserName] [varchar] (2000) NULL,
[IndexServerPassword] [varchar] (2000) NULL,
[IsBackup] [bit] NULL,
[BackupStoreID] [int] NULL,
[BackupRootPathFull] [varchar] (2000) NULL,
[BackupRootPathIncr] [varchar] (2000) NULL,
[EmailTo] [varchar] (2000) NULL,
[Emailcc] [varchar] (2000) NULL,
[FullBackupPeriodType] [varchar] (1) NULL,
[FullBackupPeriodValue] [int] NULL,
[IncrBackupDays] [int] NULL,
[LocalPath] [varchar] (2000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_FileStore] on [dbo].[FileStore]'
GO
ALTER TABLE [dbo].[FileStore] ADD CONSTRAINT [PK_FileStore] PRIMARY KEY CLUSTERED  ([FileStoreID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[FileStoreDir]'
GO
CREATE TABLE [dbo].[FileStoreDir]
(
[FileStoreDirID] [int] NOT NULL IDENTITY(1, 1),
[FileStoreID] [int] NULL,
[DirType] [varchar] (100) NULL,
[PIDUnitType1] [varchar] (100) NULL,
[PIDUnitType2] [varchar] (100) NULL,
[RelativePath] [varchar] (8000) NULL,
[RelativePathHash] [varchar] (600) NULL,
[AllowWOTStd] [varchar] (2000) NULL,
[AllowWOTPIDU] [bit] NULL,
[ObsoleteDirName] [varchar] (50) NULL,
[Description] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TemplateDir] on [dbo].[FileStoreDir]'
GO
ALTER TABLE [dbo].[FileStoreDir] ADD CONSTRAINT [PK_TemplateDir] PRIMARY KEY CLUSTERED  ([FileStoreDirID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_FileStoreDir] on [dbo].[FileStoreDir]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_FileStoreDir] ON [dbo].[FileStoreDir] ([FileStoreID], [RelativePathHash], [PIDUnitType1])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemCodeDef]'
GO
CREATE TABLE [dbo].[ItemCodeDef]
(
[ItemCodeDefID] [int] NOT NULL IDENTITY(1, 1),
[SubCATID] [int] NULL,
[GrpNum] [int] NULL,
[CodeValue] [varchar] (7) NULL,
[CodeText] [varchar] (1000) NULL,
[Remark] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ItemCodeGrpVal] on [dbo].[ItemCodeDef]'
GO
ALTER TABLE [dbo].[ItemCodeDef] ADD CONSTRAINT [PK_ItemCodeGrpVal] PRIMARY KEY CLUSTERED  ([ItemCodeDefID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemSubCatDef]'
GO
CREATE TABLE [dbo].[ItemSubCatDef]
(
[ItemSubCatDefID] [int] NOT NULL IDENTITY(1, 1),
[SubCatID] [int] NULL,
[GrpNum] [int] NULL,
[CharNum] [int] NULL,
[Name] [varchar] (1000) NULL,
[DesParamID] [int] NULL,
[MultFactor] [decimal] (18, 4) NULL,
[FixedValue] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ItemSubCatDef] on [dbo].[ItemSubCatDef]'
GO
ALTER TABLE [dbo].[ItemSubCatDef] ADD CONSTRAINT [PK_ItemSubCatDef] PRIMARY KEY CLUSTERED  ([ItemSubCatDefID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtlBusPanel]'
GO
CREATE TABLE [dbo].[PIDCtlBusPanel]
(
[PIDCtlBusPanelID] [int] NOT NULL IDENTITY(1, 1),
[PIDCtlBusID] [int] NULL,
[PanelCode] [varchar] (50) NULL,
[TermList] [varchar] (8000) NULL,
[LugList] [varchar] (8000) NULL,
[LugQty] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtlBusPanel] on [dbo].[PIDCtlBusPanel]'
GO
ALTER TABLE [dbo].[PIDCtlBusPanel] ADD CONSTRAINT [PK_PIDCtlBusPanel] PRIMARY KEY CLUSTERED  ([PIDCtlBusPanelID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtlDoc]'
GO
CREATE TABLE [dbo].[PIDCtlDoc]
(
[PIDCtlDocID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[PanelCode] [varchar] (50) NULL,
[DrgCode] [varchar] (50) NULL,
[DrgNum] [varchar] (1000) NULL,
[TypeCode] AS (case when len([panelcode])>(0) then ([drgcode]+'.')+[panelcode] else [drgcode] end),
[RevDated1] [datetime] NULL,
[RevNum1] [varchar] (50) NULL,
[RevDrnBy1] [varchar] (50) NULL,
[RevChkBy1] [varchar] (50) NULL,
[RevAppdBy1] [varchar] (50) NULL,
[RevDated2] [datetime] NULL,
[RevNum2] [varchar] (50) NULL,
[RevDrnBy2] [varchar] (50) NULL,
[RevChkBy2] [varchar] (50) NULL,
[RevAppdBy2] [varchar] (50) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtlDrg] on [dbo].[PIDCtlDoc]'
GO
ALTER TABLE [dbo].[PIDCtlDoc] ADD CONSTRAINT [PK_PIDCtlDrg] PRIMARY KEY CLUSTERED  ([PIDCtlDocID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ProdocuRev]'
GO
CREATE TABLE [dbo].[ProdocuRev]
(
[ProdocuRevID] [int] NOT NULL IDENTITY(1, 1),
[ProdocuID] [int] NULL,
[Dated] [datetime] NULL,
[Num] [varchar] (50) NULL,
[DrnBy] [varchar] (50) NULL,
[ChkBy] [varchar] (50) NULL,
[AppdBy] [varchar] (50) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ProdocuRev] on [dbo].[ProdocuRev]'
GO
ALTER TABLE [dbo].[ProdocuRev] ADD CONSTRAINT [PK_ProdocuRev] PRIMARY KEY CLUSTERED  ([ProdocuRevID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[StdDrgParam]'
GO
CREATE TABLE [dbo].[StdDrgParam]
(
[StdDrgParamID] [int] NOT NULL IDENTITY(1, 1),
[StdDrgID] [int] NULL,
[ParamName] [varchar] (50) NULL,
[Formula] [varchar] (8000) NULL,
[Descrip] [varchar] (1000) NULL,
[MinValue] [decimal] (18, 4) NULL,
[MaxValue] [decimal] (18, 4) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_StdDrgParam] on [dbo].[StdDrgParam]'
GO
ALTER TABLE [dbo].[StdDrgParam] ADD CONSTRAINT [PK_StdDrgParam] PRIMARY KEY CLUSTERED  ([StdDrgParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_StdDrgParam] on [dbo].[StdDrgParam]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_StdDrgParam] ON [dbo].[StdDrgParam] ([StdDrgID], [ParamName])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDefAction]'
GO
CREATE TABLE [dbo].[TFCompDefAction]
(
[TFCompDefActionID] [int] NOT NULL IDENTITY(1, 1),
[TFCompDefActPackID] [int] NULL,
[ActionType] [varchar] (1000) NULL,
[ActionFormula] [varchar] (1000) NULL,
[Part1Formula] [varchar] (1000) NULL,
[Ent1Formula] [varchar] (1000) NULL,
[Part2Formula] [varchar] (1000) NULL,
[Ent2Formula] [varchar] (1000) NULL,
[DistFormula] [varchar] (1000) NULL,
[QtyFormula] [varchar] (1000) NULL,
[ContOnError] [bit] NULL,
[Dist2Formula] [varchar] (1000) NULL,
[Dist3Formula] [varchar] (1000) NULL,
[Pnt1Formula] [varchar] (1000) NULL,
[Pnt2Formula] [varchar] (1000) NULL,
[BehaveFormula] [varchar] (1000) NULL,
[RotAngFormula] [varchar] (1000) NULL,
[NewNameFormula] [varchar] (1000) NULL,
[Vec1Formula] [varchar] (1000) NULL,
[Pl1Formula] [varchar] (1000) NULL,
[Qty2Formula] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefAction] on [dbo].[TFCompDefAction]'
GO
ALTER TABLE [dbo].[TFCompDefAction] ADD CONSTRAINT [PK_TFCompDefAction] PRIMARY KEY CLUSTERED  ([TFCompDefActionID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDefBOMParam]'
GO
CREATE TABLE [dbo].[TFCompDefBOMParam]
(
[TFCompDefBOMParamID] [int] NOT NULL IDENTITY(1, 1),
[TFAssyDefBOMID] [int] NULL,
[TFCompDefDetBOMID] [int] NULL,
[ParamCode] [varchar] (1000) NULL,
[Formula] [varchar] (8000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefBOMParam] on [dbo].[TFCompDefBOMParam]'
GO
ALTER TABLE [dbo].[TFCompDefBOMParam] ADD CONSTRAINT [PK_TFCompDefBOMParam] PRIMARY KEY CLUSTERED  ([TFCompDefBOMParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDefEnt]'
GO
CREATE TABLE [dbo].[TFCompDefEnt]
(
[TFCompDefEntID] [int] NOT NULL IDENTITY(1, 1),
[TFCompDefID] [int] NULL,
[WorkFeat] [bit] NULL,
[EntCode] [varchar] (50) NULL,
[EntName] [varchar] (50) NULL,
[Path1] [varchar] (50) NULL,
[Path2] [varchar] (50) NULL,
[Path3] [varchar] (50) NULL,
[Path4] [varchar] (50) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefEnt] on [dbo].[TFCompDefEnt]'
GO
ALTER TABLE [dbo].[TFCompDefEnt] ADD CONSTRAINT [PK_TFCompDefEnt] PRIMARY KEY CLUSTERED  ([TFCompDefEntID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDefParam]'
GO
CREATE TABLE [dbo].[TFCompDefParam]
(
[TFCompDefParamID] [int] NOT NULL IDENTITY(1, 1),
[TFCompDefID] [int] NULL,
[TFAssyDefID] [int] NULL,
[ParamCode] [varchar] (50) NULL,
[ParamName] [varchar] (1000) NULL,
[DataType] [int] NULL,
[Formula] [varchar] (8000) NULL,
[ParamValue] [varchar] (50) NULL,
[SortIndex] [int] NULL,
[IsInput] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefParam] on [dbo].[TFCompDefParam]'
GO
ALTER TABLE [dbo].[TFCompDefParam] ADD CONSTRAINT [PK_TFCompDefParam] PRIMARY KEY CLUSTERED  ([TFCompDefParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDefParamGrp]'
GO
CREATE TABLE [dbo].[TFCompDefParamGrp]
(
[TFCompDefParamGrpID] [int] NOT NULL IDENTITY(1, 1),
[TFCompDefID] [int] NULL,
[ShowInherited] [bit] NULL,
[GroupName] [varchar] (800) NULL,
[Description] [varchar] (1000) NULL,
[TFCompDefParamCodes] [varchar] (8000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefParamGrp] on [dbo].[TFCompDefParamGrp]'
GO
ALTER TABLE [dbo].[TFCompDefParamGrp] ADD CONSTRAINT [PK_TFCompDefParamGrp] PRIMARY KEY CLUSTERED  ([TFCompDefParamGrpID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_TFCompDefParamGrp] on [dbo].[TFCompDefParamGrp]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_TFCompDefParamGrp] ON [dbo].[TFCompDefParamGrp] ([TFCompDefID], [GroupName])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDefShot]'
GO
CREATE TABLE [dbo].[TFCompDefShot]
(
[TFCompDefShotID] [int] NOT NULL IDENTITY(1, 1),
[TFCompDefID] [int] NULL,
[Remark] [varchar] (1000) NULL,
[ShotCode] [varchar] (50) NULL,
[filetype] [varchar] (50) NULL,
[viewname] [varchar] (50) NULL,
[iPointPartFormula] [varchar] (1000) NULL,
[iPointEntFormula] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefShot] on [dbo].[TFCompDefShot]'
GO
ALTER TABLE [dbo].[TFCompDefShot] ADD CONSTRAINT [PK_TFCompDefShot] PRIMARY KEY CLUSTERED  ([TFCompDefShotID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_TFCompDefShot] on [dbo].[TFCompDefShot]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_TFCompDefShot] ON [dbo].[TFCompDefShot] ([TFCompDefID], [ShotCode])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFCompDefStdFF]'
GO
CREATE TABLE [dbo].[TFCompDefStdFF]
(
[TFCompDefStdFFID] [int] NOT NULL IDENTITY(1, 1),
[TFCompDefID] [int] NULL,
[FolderName] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFCompDefStdFF] on [dbo].[TFCompDefStdFF]'
GO
ALTER TABLE [dbo].[TFCompDefStdFF] ADD CONSTRAINT [PK_TFCompDefStdFF] PRIMARY KEY CLUSTERED  ([TFCompDefStdFFID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFDesCompRefParam]'
GO
CREATE TABLE [dbo].[TFDesCompRefParam]
(
[TFDesCompRefParamID] [int] NOT NULL IDENTITY(1, 1),
[TFDesCompRefID] [int] NULL,
[ParamCode] [varchar] (1000) NULL,
[ParamName] [varchar] (1000) NULL,
[DataType] [int] NULL,
[ParamValue] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__TFDesCompRefPara__7857F5CA] on [dbo].[TFDesCompRefParam]'
GO
ALTER TABLE [dbo].[TFDesCompRefParam] ADD CONSTRAINT [PK__TFDesCompRefPara__7857F5CA] PRIMARY KEY CLUSTERED  ([TFDesCompRefParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DesTableCols]'
GO
CREATE TABLE [dbo].[DesTableCols]
(
[DesTableColID] [int] NOT NULL IDENTITY(1, 1),
[DesTableID] [int] NULL,
[ColIndex] [int] NULL,
[ColumnName] [varchar] (1000) NULL,
[Description] [varchar] (1000) NULL,
[DataType] [int] NULL,
[Remark] [varchar] (8000) NULL,
[IsRequired] [bit] NULL,
[lowcolname] AS (lower([columnname])),
[formula] [varchar] (1000) NULL,
[useselection] [bit] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesTabCols] on [dbo].[DesTableCols]'
GO
ALTER TABLE [dbo].[DesTableCols] ADD CONSTRAINT [PK_TFDesTabCols] PRIMARY KEY CLUSTERED  ([DesTableColID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DesTableCols] on [dbo].[DesTableCols]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DesTableCols] ON [dbo].[DesTableCols] ([lowcolname], [DesTableID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFDesDefParam]'
GO
CREATE TABLE [dbo].[TFDesDefParam]
(
[TFDesDefParamID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitID] [int] NULL,
[AssyDefCode] [varchar] (50) NULL,
[ParamCode] [varchar] (50) NULL,
[ParamValue] [int] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFDesDefParam] on [dbo].[TFDesDefParam]'
GO
ALTER TABLE [dbo].[TFDesDefParam] ADD CONSTRAINT [PK_TFDesDefParam] PRIMARY KEY CLUSTERED  ([TFDesDefParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[TFNestSheet]'
GO
CREATE TABLE [dbo].[TFNestSheet]
(
[TFNestSheetID] [int] NOT NULL IDENTITY(1, 1),
[TFNestID] [int] NULL,
[LayoutNum] [int] NULL,
[Width] [int] NULL,
[Length] [int] NULL,
[perUtil] [decimal] (18, 2) NULL,
[cncdrg] [varchar] (1000) NULL,
[ncfile] [varchar] (1000) NULL,
[PartXML] [varchar] (max) NULL,
[cncdrgrem] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_TFNestSheet] on [dbo].[TFNestSheet]'
GO
ALTER TABLE [dbo].[TFNestSheet] ADD CONSTRAINT [PK_TFNestSheet] PRIMARY KEY CLUSTERED  ([TFNestSheetID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_TFNestSheet] on [dbo].[TFNestSheet]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_TFNestSheet] ON [dbo].[TFNestSheet] ([TFNestID], [LayoutNum])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDCtl]'
GO
CREATE TABLE [dbo].[PIDCtl]
(
[PIDCtlID] [int] NOT NULL IDENTITY(1, 1),
[CtlItemID] [int] NULL,
[PIDUnitID] [int] NULL,
[CtlCktID] [int] NULL,
[Qty] [varchar] (1000) NULL,
[DescripSuffix] [varchar] (1000) NULL,
[DescripPrefix] [varchar] (1000) NULL,
[Legend] [varchar] (850) NULL,
[LegendCable] [varchar] (1000) NULL,
[Location] [varchar] (50) NULL,
[CP] [bit] NULL CONSTRAINT [DF_PIDCtl_CP] DEFAULT ((0)),
[Price] [decimal] (18, 2) NULL,
[TerminalNumXML] [varchar] (1000) NULL,
[CompImageWD] [image] NULL,
[IsParTB] [bit] NULL,
[Legends] [varchar] (8000) NULL,
[GAUse] [varchar] (1000) NULL,
[QtyNum] [int] NULL,
[QtyNet] [int] NULL,
[QtyPrint] [varchar] (50) NULL,
[LegendsGA] [varchar] (8000) NULL,
[PIDCtlKey] AS (case when isnull([legend],'')='' OR isnull([legend],'')='' then CONVERT([varchar],[pidctlid],(0)) else [legend] end),
[LugQty] [int] NULL,
[LugTypeText] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDCtl] on [dbo].[PIDCtl]'
GO
ALTER TABLE [dbo].[PIDCtl] ADD CONSTRAINT [PK_PIDCtl] PRIMARY KEY CLUSTERED  ([PIDCtlID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ItemVMS]'
GO
CREATE TABLE [dbo].[ItemVMS]
(
[ItemVMSID] [int] NOT NULL IDENTITY(1, 1),
[ItemID] [int] NULL,
[Packing] [varchar] (8000) NULL,
[KanSpecs] [varchar] (8000) NULL,
[VMSIndex] [int] NULL,
[Version] AS ('Version '+CONVERT([varchar](10),[vmsindex],(0))),
[SuppSpec] [varchar] (8000) NULL,
[SpecNum] [int] NULL,
[RevNum] [int] NULL,
[IsCurrent] [bit] NULL CONSTRAINT [DF_ItemVMS_IsCurrent] DEFAULT ((1)),
[Make] [varchar] (1000) NULL,
[SpecWrite] AS ((('S'+CONVERT([varchar],[specnum],(0)))+'R')+CONVERT([varchar],[revnum],(0))),
[SpecWriteMake] AS (((('S'+CONVERT([varchar],[specnum],(0)))+'R')+CONVERT([varchar],[revnum],(0)))+case when ltrim(rtrim(isnull([make],'')))='' then '' else '-'+[make] end),
[SpecMatSpec] [varchar] (1000) NULL,
[HasBOM] [bit] NULL,
[SubCATID] [int] NULL,
[PIDUnitID] [int] NULL,
[VarNum] [int] NULL,
[SelectFormula] [varchar] (8000) NULL,
[vxValue] [decimal] (18, 4) NULL,
[vyValue] [decimal] (18, 4) NULL,
[KanSpecsDDNum] [varchar] (8000) NULL,
[CreatedBy] [varchar] (50) NULL,
[CreatedOn] [datetime] NULL,
[LastModBy] [varchar] (50) NULL,
[LastModOn] [datetime] NULL,
[LastModApp] [varchar] (50) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_ItemVMS] on [dbo].[ItemVMS]'
GO
ALTER TABLE [dbo].[ItemVMS] ADD CONSTRAINT [PK_ItemVMS] PRIMARY KEY CLUSTERED  ([ItemVMSID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_ItemVMS] on [dbo].[ItemVMS]'
GO
CREATE NONCLUSTERED INDEX [IX_ItemVMS] ON [dbo].[ItemVMS] ([ItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_ItemVMS_1] on [dbo].[ItemVMS]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_ItemVMS_1] ON [dbo].[ItemVMS] ([ItemID], [SpecNum], [RevNum], [SubCATID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_ItemVMS_2] on [dbo].[ItemVMS]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_ItemVMS_2] ON [dbo].[ItemVMS] ([ItemID], [VMSIndex], [SubCATID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[invListItems]'
GO










CREATE                    function [dbo].[invListItems]()
returns table
return (


select items.itemid,items.itemname,ItemUnits.NameSingular,
itemunits.itemunitid,itemunits.nameplural as unitname,items.acceptwo,
items.itemcode + '-' + items.itemname as iteminfo,
items.minorderqty, itemsubcats.classabc, items.[application],
items.purchaseprice,items.purchpricelastupd,itemscheds.schedcode,
isnull(itemsubcats.costingtype,0) as costingtype, itemscheds.pxmlc,
itemsubcats.perwastage,itemsubcats.drgbomname,

cnctypes.isgasket, cnctypes.initemcollec, cnctypes.ishardware, cnctypes.titleqc,
case when itemsubcats.costingtype=1 then items.costingitemid 
	when itemsubcats.costingtype=2 then itemsubcats.costingitemid
else null end as costingitemid,

itemsubcats.oldscname,items.oldcode,items.oldname,
isnull(itemsubcats.isstock,0) as  isstock,
items.shortname,items.paramlayoutcols,items.itemsizeid,
ItemUnits.NamePlural,Items.ItemCode,ItemSubcats.subcatid,
itemsubcats.invcatid,items.matspec,items.matlistok,items.qtyasreq,items.qtydef,

itemsubcats.hasdefs, xvalue,yvalue,zvalue,svalue,pValue, itemsubcats.keeptrack,
itemsubcats.pvaluea,itemsubcats.pvalueb,itemsubcats.pvaluec,itemsubcats.pvalued,itemsubcats.pvaluee,
cnctypes.cnctypeid, cnctypes.cnctypename, cnctypes.weldedtypeid,itemsubcats.bomsectiontypecode,
items.minlevel,items.warnlevel,items.shelflife,
items.wtperno,
items.bomthk,
items.bommatsection,
itemsubcats.density,
items.wtpermtr,
items.areapermtr,
items.sectiondim1, items.sectiondim2, items.sectiondim3,

itemsubcats.initialcode,itemsubcats.subcatname,
itemscheds.itemschedid,itemscheds.schedname,
itemsubcats.xname,itemsubcats.yname,itemsubcats.zname,itemsubcats.sname,itemsubcats.pname

from items
	inner join itemsubcats on items.subcatid = itemsubcats.subcatid
	inner join itemunits on itemsubcats.itemunitid = itemunits.itemunitid
	inner join itemscheds on itemsubcats.itemschedid = itemscheds.itemschedid
	left join cnctypes on itemsubcats.cnctypeid = cnctypes.cnctypeid











)









GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fncStWriteAs]'
GO




CREATE    function dbo.fncStWriteAs(@itemvmsid int )
returns varchar(500)
begin
	declare @stwriteas varchar(500)	
	declare @temp varchar(255)
	declare VMSCurs cursor fast_forward
	for
	
		select stanspecs.writeas from 
		itemspecs left join stanspecs 
		on itemspecs.stanspecid=stanspecs.stanspecid
		where itemspecs.itemvmsid=@itemvmsid		
	
	open vmsCurs
	set @stwriteas=''
	while (0=0) begin
		fetch next  from vmsCurs into @temp
		if (@@fetch_status<>0) break
		if @stwriteas<>'' set @stwriteas = @stwriteas + ', '
		set @stwriteas=@stwriteas + @temp
	end
	if @stwriteas='' set @stwriteas=null

	return @stwriteas
end














GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListCtlItems]'
GO







CREATE function [dbo].[desListCtlItems]()
returns table
	return (


select ctlitemid,  ctlitems.haswd,ctlitems.DontPrintInMatList,ctlitems.lugtype,
ctlitems.mtgmbid,ctlitems.mtgcpid, isnull(ctlitems.istb,0) as istb,ctlitems.isold,
ili.itemid,ili.itemname,ili.NameSingular,
ili.itemunitid,ili.nameplural as unitname,ili.acceptwo,

ili.shortname,ili.paramlayoutcols,ili.itemsizeid,
ili.NamePlural,ili.subcatid,
ili.invcatid,

ili.hasdefs, xvalue,yvalue,zvalue,svalue,pvalue, ili.keeptrack,
ili.minlevel,ili.warnlevel,ili.shelflife,

ili.initialcode,ili.subcatname,ili.itemschedid,ili.schedname,

ili.xname,ili.yname,ili.zname,ili.sname,ili.pname,
ili.qtydef,ili.qtyasreq,ili.matlistOK,

isnull(itemvms.itemvmsid, 0) as itemvmsid,

itemvms.packing, itemvms.iscurrent,
itemvms.specwrite,itemvms.specwritemake, dbo.fncStWriteAs(Itemvms.itemvmsid) as StdSpec,
itemvms.vmsindex,itemvms.specnum,itemvms.revnum,itemvms.specmatspec,

coalesce(ctlitems.ganameitem, ctlcat.ganamecat, ctlcat.ctlcat) as ganame,
ctlitems.garating,
coalesce(ctlitems.gamakesitem,ctlcat.gamakescat) as gamakes,

ctlcat.ctlcatid,
ctlitems.pricelastupdated,
CtlCat, 

case when itemvms.itemvmsid is null then 
ctlitems.itemcode
else ili.ItemCode + '-' + itemvms.specwrite end as ItemCode,

case when itemvms.itemvmsid is null then ctlitems.ctlitem + case when isnull(ctlitems.descrip,'')='' then '' else '  - '+ char(10) + char(13) + ctlitems.descrip end
else 
		case when isnull(itemvms.specmatspec,'')='' then 
			ili.itemname
	else itemvms.specmatspec end  

end as Item, 

case when itemvms.itemvmsid is null then ''
else itemvms.kanspecs end as Spec,

case when itemvms.itemvmsid is null then ctlitems.ctlMake else itemvms.make end as Make, 

case when itemvms.itemvmsid is null then 'Cat No. ' + ctlitems.CatNum else itemvms.suppspec end as SuppSpec, 

Legend, 
Purpose, 
MtgMB,MtgCP,
Loc, Price,
Remark


from ctlitems
	left join itemvms on ctlitems.itemvmsid = itemvms.itemvmsid
	left join invlistitems() as ili on itemvms.itemid = ili.itemid
	left join ctlcat on ctlitems.ctlcatid = ctlcat.ctlcatid
)

























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ctsListPIDCtlTerm]'
GO












CREATE     function [dbo].[ctsListPIDCtlTerm]()
returns table
	return (


select pidctlterm.pidctltermid, pidctl.pidunitid, pidctl.location, pidctlbus.pidctlbusid,pidctl.pidctlid,
case when len(isnull(pidctl.legendcable,''))>0 then pidctl.legendcable else pidctl.legend end as legendcable,

pidctl.Legend + case when isnull(pidctlpanel.paneltype,0)=4 and isnull(pidctlpanel.fieldins,0)=1 then '' else
':'+pidctlterm.terminalname end as Terminal, 

pidctlpanel.DrawingNoteTB,

pidctlterm.wirelooptermid, pidctlterm.pidctlcableidfa,
pidctlterm.reducebottomtbline, pidctlterm.cabledescriptbprint, pidctlterm.lugqty,
upper(pidctl.Location) +'-'+pidctl.Legend+':'+pidctlterm.terminalname as TerminalTot, 

	ctlitems.istb,pidctlterm.internaltermid,pidctlterm.externaltermid,ctlitems.lugholedia,ctlitems.lugtype,
	pidctlpanel.panelcode, pidctlpanel.panelname, pidctlpanel.paneltype,pidctlpanel.fieldins,
	ctlitemtermset.devsepcable,pidctl.ispartb,pidctltermid2,
	pidctlbus.wirenum,pidctlbus.sqmm,pidctlbus.Color,

	pidctl.legend,pidctlterm.terminalname,pidctlterm.sortindexwire


from pidctlterm
	inner join pidctl on pidctlterm.pidctlid = pidctl.pidctlid
	inner join ctlitems on pidctl.ctlitemid = ctlitems.ctlitemid
	left join pidctlbus on pidctlterm.pidctlbusid = pidctlbus.pidctlbusid
	left join ctlitemtermset on pidctlterm.ctlitemtermsetid = ctlitemtermset.ctlitemtermsetid
	left join pidctlpanel on pidctl.location = pidctlpanel.panelcode and pidctlpanel.pidunitid = pidctl.pidunitid

)





























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[invListItemSpecs]'
GO









CREATE               function [dbo].[invListItemSpecs]()
returns table
return (


SELECT ItemVMS.ItemVMSID, Stanspecs.stanspecid,  itemvms.subcatid,
	itemspecs.itemspecid,
	itemvms.itemid,
	itemvms.kanspecs, itemvms.packing,
	stanSpecs.SpecNum, 
	stanspecs.writeas
 
FROM itemvms 
	left join (itemspecs inner join stanspecs on stanspecs.stanspecid=itemspecs.stanspecid) 
	on itemvms.itemvmsid = itemspecs.itemvmsid





)






























GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ctsListPIDCable]'
GO













CREATE function [dbo].[ctsListPIDCable]()
returns table
	return (


select pidctlcable.pidctlcableid, pidctlcable.pidunitid,
pct1.terminalname as terminalname1, pct2.terminalname as terminalname2,pidctlcable.sqmm,
	pidctlcable.Loc1+'-'+pct1.Legend+'.'+pct1.terminalname as Term1, 
	pidctlcable.Loc2+'-'+pct2.Legend+case when isnull(pct2.terminalname,'')='' then '' else '.'+pct2.terminalname end as Term2, 
	pidctlconn.pidctltermid1,pct1.paneltype as paneltype1, pidctlconn.pidctltermid2, pct2.paneltype as paneltype2,
	isnull(pct1.istb,0) as istb1, isnull(pct2.istb,0) as istb2, pidctlcable.cabledescriptb,

	pidctlcable.Loc1 + ' - ' + pidctlcable.Loc2 as Loc,

	pidctlCable.CableName,
	pidctlCable.CableName+ ' - ' + convert(varchar,pidctlCable.NumCores) + ' Core' as CableDescrip,

	pidctlCable.NumCores,
	pct1.WireNum,
	isnull(pidctlcable.Loc1,'') as Loc1, pct1.Legend as Device1, dbo.val(pct1.terminalname) as Terminal1, 
	isnull(pidctlcable.Loc2,'') as Loc2, pct2.Legend as Device2,case when pct2.terminalname is null then null else dbo.val(pct2.terminalname) end as Terminal2

from pidctlconn 
	inner join pidctlcable on pidctlconn.pidctlcableid = pidctlcable.pidctlcableid
	left join ctslistpidctlterm() as pct1 on pidctlconn.pidctltermid1 = pct1.pidctltermid
	left join ctslistpidctlterm() as pct2 on pidctlconn.pidctltermid2 = pct2.pidctltermid

)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ctsListPIDTB]'
GO











CREATE function [dbo].[ctsListPIDTB]()
returns table
	return (


select pct.pidctltermid, pct.pidunitid, pct.location, pct.pidctlbusid,
	pct.istb,pct.internaltermid,pct.externaltermid,
	pct.DrawingNoteTB,
	isnull(pct.reducebottomtbline,0) as reducebottomtbline, pct.cabledescriptbprint,
	pct.Terminal,
	pctin.terminaltot as TermInt, 
	pctex.terminaltot as TermExt, 

	pct.sqmm,pct.Color,pct.sortindexwire,

	pct.Legend,

	upper(pctin.Location) as LocInt,pctin.Terminal as DeviceInt, 
	pct.WireNum, pctwl.Terminal as WireLoop,
	dbo.val(pct.terminalname) as TerminalName,
	upper(pctex.Location) as LocExt,pctex.Terminal as DeviceExt,
	pidctlcable.CableDescripTB
	

from ctslistpidctlterm() as pct
	left join ctslistpidctlterm() as pctin on pct.internaltermid = pctin.pidctltermid
	left join ctslistpidctlterm() as pctex on pct.externaltermid = pctex.pidctltermid
	left join ctslistpidctlterm() as pctwl on pct.wirelooptermid = pctwl.pidctltermid
	left join pidctlcable on pct.pidctlcableidfa = pidctlcable.pidctlcableid
	
	where isnull(pct.istb,0)=1

)




























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[invListItemSubCats]'
GO








CREATE                      function [dbo].[invListItemSubCats]()
returns table
return (


select ItemUnits.NameSingular,
itemunits.itemunitid,itemunits.nameplural as unitname,
itemsubcats.strmaint,itemscheds.schedcode,
ItemUnits.NamePlural,ItemSubcats.subcatid,itemsubcats.invcatid,

cnctypes.isgasket, cnctypes.initemcollec, cnctypes.cnctypeid, cnctypes.cnctypename,

itemsubcats.vendorlisthead,itemsubcats.purchasespec,

itemsubcats.hasdefs,itemsubcats.hasdefscost,itemsubcats.keeptrack,
itemsubcats.bomsectiontypecode,itemsubcats.intankdrawings, itemsubcats.drgbomname, itemsubcats.density,

itemsubcats.dim1param, itemsubcats.dim2param, itemsubcats.dim3param,
isnull(itemsubcats.costingtype,0) as costingtype,itemsubcats.costingitemid,
itemsubcats.paramxmlx, itemsubcats.paramxmly, itemsubcats.paramxmlz, itemsubcats.paramxmlp, itemsubcats.paramxmls, 

case when isnull(iswospecific,0)=1 then 'WO Specific' + case when isnull(ismacmaint,0)=1 then ' / ' else '' end 
else '' end
+ case when isnull(ismacmaint,0)=1 then 'Machinery Maintenance' + case when isnull(isstock,0)=1 then ' / ' else '' end else '' end
+ case when isnull(iswospecific,0)=1 and isnull(ismacmaint,0)=0 and isnull(isstock,0)=1 then ' / ' else '' end
+ case when isnull(isstock,0)=1 then 'Stock' else '' end as SubCatType,

itemsubcats.initialcode,itemsubcats.subcatname,itemscheds.itemschedid,itemscheds.schedname,
itemsubcats.xname,itemsubcats.yname,itemsubcats.zname,itemsubcats.sname,itemsubcats.pname,
itemsubcats.xnamecost,itemsubcats.ynamecost,itemsubcats.znamecost,itemsubcats.snamecost,itemsubcats.pnamecost

from itemsubcats
	inner join itemunits on itemsubcats.itemunitid = itemunits.itemunitid
	inner join itemscheds on itemsubcats.itemschedid = itemscheds.itemschedid
	left join cnctypes on itemsubcats.cnctypeid = cnctypes.cnctypeid










)









































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListPIDCtlTerm]'
GO







CREATE    function [dbo].[desListPIDCtlTerm]()
returns table
	return (


select  pidctl.pidunitid, pidctl.pidctlid,desListCtlItems.ctlitemid,cp,
descripprefix,descripsuffix,deslistctlitems.itemid, deslistctlitems.subcatid,
deslistctlitems.istb,pidctlterm.pidctltermid2,
pidctl.Legend+'.'+pidctlterm.terminalname as Terminal, 
upper(pidctl.Location) +'-'+pidctl.Legend+'.'+pidctlterm.terminalname as TerminalTot, 

isnull(deslistctlitems.itemvmsid,0) as itemvmsid,  
desListCtlItems.MtgMB,desListCtlItems.MtgCP,pidctl.location,
pidctlpanel.panelcode,pidctlpanel.panelname,pidctlpanel.paneltype,
case when cp=0 then 'Marshalling Box' else 'RTCC' end as Loc,
pidctl.Qty,
pidctlterm.pidctlbusid,pidctlterm.pidctltermid,pidctlbus.wirenum,
deslistctlitems.ItemCode,
pidctlterm.sortindexctl, pidctlterm.sortindexwire,
deslistCtlItems.Item, 
case when cp=0 then mtgmb else mtgcp end as Mtg,

isnull(pidctl.descripprefix,'') + desListCtlItems.Spec + isnull(pidctl.descripsuffix,'')
as Spec,

deslistctlitems.Make, 

deslistctlItems.SuppSpec,  


CtlCat, 

pidctl.Legend,

pidctlterm.TerminalName



from pidctlterm 
	inner join pidctl on pidctlterm.pidctlid = pidctl.pidctlid
	inner join deslistctlitems() on pidctl.ctlitemid = deslistctlitems.ctlitemid
	left join pidctlbus on pidctlterm.pidctlbusid = pidctlbus.pidctlbusid
	left join pidctlpanel on pidctl.location = pidctlpanel.panelcode and pidctlpanel.pidunitid = pidctl.pidunitid
)
























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ctsListPIDCtlLug]'
GO











CREATE function [dbo].[ctsListPIDCtlLug]()
returns table
	return (


select pidctlbus.pidunitid,ctslistpidctlterm.location, ctslistpidctlterm.panelname as loc, ili.itemid, ili.ItemCode, ili.ItemName, 
pidctlbustermid, pidctlbus.pidctlbusid, pidctlbusterm.lugqty

from pidctlbusterm 
inner join ctslistpidctlterm() on pidctlbusterm.pidctltermid = ctslistpidctlterm.pidctltermid
inner join PIDCtlBus on pidctlbusterm.pidctlbusid = pidctlbus.pidctlbusid 
inner join invlistitems() as ili on pidctlbusterm.lugitemid = ili.itemid



)
























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[cadListTFCDActPack]'
GO







CREATE function [dbo].[cadListTFCDActPack]()
returns table
	return (


select tfcdap.tfcompdefactpackid, tfcdap.parentactpackid,
tfcdap.tfcompdefid, 

isnull(tfcdap2.tfcompdefactpackid,tfcdap.tfcompdefactpackid) as procactpackid,

case when tfcdap2.tfcompdefactpackid is null then tfcdap.contonerror else tfcdap2.contonerror end as contonerror,

tfcd2.descrip as ParentAPComp,
tfcompdef.Descrip as Component, 


case when tfcdap2.tfcompdefactpackid is null then tfcdap.Descrip else tfcdap2.descrip end as Descrip,

case when tfcdap2.tfcompdefactpackid is null then tfcdap.evalcondition else tfcdap2.evalcondition end as evalcondition

from tfcompdefactpack as tfcdap
inner join tfcompdef on tfcdap.tfcompdefid = tfcompdef.tfcompdefid
left join tfcompdefactpack as tfcdap2 on tfcdap.parentactpackid = tfcdap2.tfcompdefactpackid
left join tfcompdef as tfcd2 on tfcdap2.tfcompdefid = tfcd2.tfcompdefid
)






















































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListItems]'
GO

















CREATE    function [dbo].[desListItems]()
returns table
return (


select items.itemid,

case when items.itemid is null then 'No items in this sub cat' else items.itemname end as ItemName,


ItemUnits.NameSingular,items.bomnonstd,
itemunits.itemunitid,itemunits.nameplural as unitname,items.acceptwo,

items.shortname,items.paramlayoutcols,items.itemsizeid,
ItemUnits.NamePlural,Items.ItemCode,ItemSubcats.subcatid,


itemsubcats.intankdrawings, cnctypes.isgasket, cnctypes.ishardware, cnctypes.initemcollec,cnctypes.weldedtypeid,
coalesce(items.drgbomname, itemsubcats.drgbomname, itemsubcats.subcatname) as  drgbomname,
cnctypes.bomsepcharts,
itemsubcats.bomsectiontypecode, cnctypes.cnctypeid,cnctypes.cnctypename,
items.bomthk,
items.bommatsection,
itemsubcats.density,
items.wtpermtr,
items.areapermtr,
items.wtperno,
itemsubcats.dim1param, itemsubcats.dim2param, itemsubcats.dim3param,
items.sectiondim1, items.sectiondim2, items.sectiondim3,
itemsubcats.pvaluea, itemsubcats.pvalueb, itemsubcats.pvaluec, itemsubcats.pvalued, itemsubcats.pvaluee,

itemsubcats.hasdefs, xvalue,yvalue,zvalue,svalue,pvalue, 
items.minlevel,items.warnlevel,items.shelflife, 

itemsubcats.initialcode,itemsubcats.subcatname,itemscheds.itemschedid,itemscheds.schedname,

itemsubcats.xname,itemsubcats.yname,itemsubcats.zname,itemsubcats.sname,itemsubcats.pname,
itemsubcats.paramxmlx, itemsubcats.paramxmly, itemsubcats.paramxmlz, itemsubcats.paramxmlp, itemsubcats.paramxmls, 

items.matspec,items.qtydef,items.qtyasreq,items.matlistOK



from itemsubcats
	left join items on items.subcatid = itemsubcats.subcatid
	inner join itemunits on itemsubcats.itemunitid = itemunits.itemunitid
	inner join itemscheds on itemsubcats.itemschedid = itemscheds.itemschedid
	left join cnctypes on itemsubcats.cnctypeid = cnctypes.cnctypeid








)
















































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDUnit]'
GO
CREATE TABLE [dbo].[PIDUnit]
(
[PIDUnitID] [int] NOT NULL IDENTITY(1, 1),
[PIDUnitType] [varchar] (100) NULL,
[Customer] [varchar] (1000) NULL,
[Descrip] [varchar] (50) NULL,
[WONum] [varchar] (50) NULL,
[FileNum] [varchar] (900) NULL,
[FileVol] [int] NULL,
[FileNumComp] AS ([FileNum]+case when isnull([filevol],(0))>(0) then ' - Vol. '+CONVERT([varchar],[filevol],(0)) else '' end),
[IsCompleted] [bit] NULL CONSTRAINT [DF_PIDUnit_IsCompleted] DEFAULT ((0)),
[OrderDate] [datetime] NULL,
[DesignDate] [datetime] NULL,
[Remarks] [varchar] (1000) NULL,
[StartupDefID] [int] NULL,
[StartupDefACID] [int] NULL,
[Lastupdated] [datetime] NULL,
[TemplateFileName] [varchar] (8000) NULL,
[PIDInfo] AS (([descrip]+'-')+[customer]),
[HasAssyMatList] [bit] NULL,
[MtGABomSort] [bit] NULL,
[PackListNote] [text] NULL,
[HWMaterial] [int] NULL,
[HWMaterialDescrip] [varchar] (1000) NULL,
[HWMaterial2] [int] NULL,
[HWMaterial2Descrip] [varchar] (1000) NULL,
[HWMaterial2MaxDia] [decimal] (18, 2) NULL,
[FolderName] [varchar] (2000) NULL,
[WOFolderAllow] [varchar] (1000) NULL,
[CoreGroupNum] [int] NULL,
[WdgGroupNum] [int] NULL,
[TankGroupNum] [int] NULL,
[Fileroot] [varchar] (1000) NULL,
[Invroot] [varchar] (1000) NULL,
[MfgTypeCode] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__PDUnit__18AD54BE] on [dbo].[PIDUnit]'
GO
ALTER TABLE [dbo].[PIDUnit] ADD CONSTRAINT [PK__PDUnit__18AD54BE] PRIMARY KEY CLUSTERED  ([PIDUnitID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_PIDUnit_1] on [dbo].[PIDUnit]'
GO
CREATE NONCLUSTERED INDEX [IX_PIDUnit_1] ON [dbo].[PIDUnit] ([FileNum])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[cadListTFCompRef]'
GO



CREATE function [dbo].[cadListTFCompRef]()
returns table
	return (


select  tfdescomprefid, tfcompdef.TFCompDefID      ,CompDefCode      ,DTBased      ,DesTableID      ,DesTableCode
      ,DTLocalParamCode      ,DTSelColCode      ,DTDispColKeys      ,tfcompdef.CompFileName      ,
	CreateNewASM      ,TreatLib      ,ParamBehave      ,Comp2D      ,
	isnull(tfcompdefdetbom.BlockName,tfcompdef.blockname) as BlockName      ,IntDesignCode,

deepcopyfiles,md5hashcode,baselastmodified,compdefpath,
ErrorCode,pCompRefID,tfdescompref.pidunitid,tfdescompref.isold,tfcompdefdetbom.createcopy,

tfdescompref.sortindex,Descrip,tfcompdefdetbom.NewName,BaseFileName,NewFileName,Qty,ErrorDescrip

from tfdescompref
inner join tfcompdef on tfdescompref.tfcompdefid = tfcompdef.tfcompdefid
left join tfcompdefdetbom on tfdescompref.tfcompdefdetbomid = tfcompdefdetbom.tfcompdefdetbomid
)






















































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[cadListTFPartDef]'
GO







CREATE function [dbo].[cadListTFPartDef]()
returns table
	return (


select  TFPartDefID, tfpartdefcat.TFPartDefCatID,TFPartDefCodeCalc,
items.itemid,
	ParamXML,ParamDescrip,DescripFinal,
	[Param1Name],[Param2Name],[Param3Name],[Param4Name],[Param5Name],[Param6Name],[Param7Name],
	
	[Descrip],[TFPartDefClass],[TFPartDefClassName],TypeNum,
	Param1Value,Param2Value,Param3Value,Param4Value,Param5Value,Param6Value,Param7Value,
	CSDia,
	InnerDia,OuterDia,Thk,Lo,Li,Bo,Bi,Wid,L1,L2,Drg,TFPartDefCode,
	Items.ItemCode,
	ChartDescrip,
	Remark

from tfpartdef
inner join tfpartdefcat on tfpartdef.tfpartdefcatid = tfpartdefcat.tfpartdefcatid
left join items on items.itemid = tfpartdef.itemid
)






















































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[cadListTFAssyParts]'
GO







CREATE function dbo.cadListTFAssyParts()
returns table
	return (


select  tfpartdef.TFPartDefID, tfpartdefcat.TFPartDefCatID,TFPartDefCodeCalc,TFPartDefCode,
tfassydefbom.tfassydefbomid,tfassydefbom.tfassydefid,
	ParamXML,ParamDescrip,DescripFinal,sortindex,bomtype,
	[Param1Name],[Param2Name],[Param3Name],[Param4Name],[Param5Name],[Param6Name],[Param7Name],
	
	HWMainElemType,HWDiaFormula,HWLenFormula,PWNum,SWNum,LockNutNum,FullNutNum,

	tfassydefbom.Descrip,[TFPartDefClass],[TFPartDefClassName],TypeNum,
	Param1Value,Param2Value,Param3Value,Param4Value,Param5Value,Param6Value,Param7Value,
	
	InnerDia,OuterDia,Thk,Lo,Li,Bo,Bi,Wid,L1,L2,Drg,
	[QtyFormula],
	[QtyFormulaTanking],[QtyFormulaTrptIfDet],[QtyFormulaTrptIfNoDet],[QtyFormulaErection],
	Remark

from tfassydefbom
inner join tfassydef on tfassydefbom.tfassydefid = tfassydef.tfassydefid
left join tfpartdef on tfassydefbom.childpartdefid = tfpartdef.tfpartdefid
left join tfpartdefcat on tfpartdef.tfpartdefcatid = tfpartdefcat.tfpartdefcatid

)






















































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListTFAssyMat]'
GO






CREATE function [dbo].[desListTFAssyMat]()
returns table
	return (


select tfdesassymat.pidunitid, 
tfdesassymat.parentcasecode,
TFDesAssyMatID,tfdesassymat.DefCode,tfdesassymat.TFPartDefID,
tfpartdef.TFPartDefCodeCalc,tfpartdef.TFPartDefCode,tfpartdef.TypeNum,itemnumst,
tfpartdefcat.ignorepipeline,
items.itemid, IsParent,tfdesassymat.sparam,tfdesassymat.chartsuffix, 

pidunit.packlistnote,

tfdesassymat.HWMainElemType,tfdesassymat.HWDia,tfdesassymat.HWLen, pidunit.hwmaterialdescrip,
tfdesassymat.HWMainElem,tfdesassymat.HWSize,tfdesassymat.isweldedhw,
tfdesassymat.PWNum,tfdesassymat.SWNum,tfdesassymat.LockNutNum,tfdesassymat.FullNutNum,
tfpartdefcat.TFPartDefCatID,tfpartdefcat.Descrip as CatDescrip,tfpartdefcat.TFPartDefClass,tfpartdefcat.TFPartDefClassName,
tfpartdefcat.Param1Name,tfpartdefcat.Param2Name,tfpartdefcat.Param3Name,tfpartdefcat.Param4Name,
tfpartdefcat.Param5Name,tfpartdefcat.Param6Name,tfpartdefcat.Param7Name,

tfdesbomga.itemnum,
case when tfpartdef.tfpartdefid is null then 
	case when isnull(tfdesassymat.hwdia,0)>0 then tfdesassymat.descrip else 'Assy Item' end
else
	isnull(tfpartdefcat.tfpartdefclasschname,tfpartdefcat.tfpartdefclassname) 
+ case when len(isnull(tfpartdef.tfpartdefcode,''))>0 then ' Code ' + isnull(tfpartdef.tfpartdefcode,'')
		when len(isnull(tfpartdef.drg,''))>0 then ' Drg ' + isnull(tfpartdef.drg,'') else '' end
end 
+ case when isnull(tfdesassymat.chartsuffix,'')<>'' and len(isnull(tfdesassymat.parentcasecode,''))=0 then ' ' + tfdesassymat.chartsuffix else '' end
+ case when len(isnull(tfdesassymat.sparam,''))>0 then ' ' + tfdesassymat.sparam else '' end
as partdescrip,

case when ((tfdesbomga.tfdesbomgaid is not null) and isnull(tfdesassymat.isparent,0)=1) or isnull(tfdesassymat.descrip,'')='' or isnull(tfdesassymat.hwdia,0)>0 then 
isnull(tfdesbomga.namechart,tfdesbomga.description) else isnull(tfdesassymat.Descrip,'') end 
+ case when isnull(tfpartdef.chartdescrip,'')<>'' then ' ' + tfpartdef.chartdescrip else '' end
+ case when isnull(tfdesassymat.chartsuffix,'')<>'' then ' ' + tfdesassymat.chartsuffix else '' end
as Descrip, 
tfpartdef.Param1Value,tfpartdef.Param2Value,tfpartdef.Param3Value,tfpartdef.Param4Value,
tfpartdef.Param5Value,tfpartdef.Param6Value,tfpartdef.Param7Value,

	tfpartdef.CSDia,tfpartdef.InnerDia,tfpartdef.OuterDia,tfpartdef.Thk,
tfpartdef.Lo,tfpartdef.Li,tfpartdef.Bo,tfpartdef.Bi,tfpartdef.Wid,tfpartdef.L1,tfpartdef.L2,
tfpartdef.Drg
+ case when len(isnull(tfdesassymat.sparam,''))>0 then ' ' + tfdesassymat.sparam else '' end as Drg,


tfpartdef.DescripFinal,



tfdesassymat.QtyTanking, 

case when isnull(tfpartdefcat.ignorepipeline,0)=1 then
	case when tfdesassymat.QtyTransport>0 then tfdesassymat.QtyTransport else 0 end
else tfdesassymat.QtyTransport end as QtyTransport,


tfdesassymat.QtyErection,

tfpartdef.Remark

from tfdesassymat
inner join pidunit on tfdesassymat.pidunitid = pidunit.pidunitid
left join tfdesbomga on tfdesassymat.defcode =tfdesbomga.defcode and tfdesassymat.pidunitid = tfdesbomga.pidunitid
left join tfpartdef on tfdesassymat.tfpartdefid = tfpartdef.tfpartdefid
left join tfpartdefcat on tfpartdef.tfpartdefcatid = tfpartdefcat.tfpartdefcatid
left join items on items.itemid = isnull(tfdesassymat.ItemID,tfpartdef.itemid)
)
























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListTFPackList]'
GO







CREATE  function [dbo].[desListTFPackList]()
returns table
	return (


select deslisttfassymat.pidunitid, 
tfdespacklist.tfdespacklistid,
deslisttfassymat.TFDesAssyMatID,deslisttfassymat.DefCode,deslisttfassymat.TFPartDefID,
deslisttfassymat.TFPartDefCodeCalc,deslisttfassymat.TFPartDefCode,deslisttfassymat.TypeNum,

deslisttfassymat.itemid, IsParent,deslisttfassymat.packlistnote,deslisttfassymat.isweldedhw,
case when isnull(ignorepipeline,0)=1 then 0 else tfdespacklist.qtyop2 end as qtyop2,

deslisttfassymat.HWMainElemType,deslisttfassymat.HWDia,deslisttfassymat.HWLen,
deslisttfassymat.HWMainElem,deslisttfassymat.HWSize,
deslisttfassymat.PWNum,deslisttfassymat.SWNum,deslisttfassymat.LockNutNum,deslisttfassymat.FullNutNum,
deslisttfassymat.TFPartDefCatID,deslisttfassymat.Descrip as CatDescrip,deslisttfassymat.TFPartDefClass,deslisttfassymat.TFPartDefClassName,
deslisttfassymat.Param1Name,deslisttfassymat.Param2Name,deslisttfassymat.Param3Name,deslisttfassymat.Param4Name,
deslisttfassymat.Param5Name,deslisttfassymat.Param6Name,deslisttfassymat.Param7Name,

case when casenum is null then 'During Tanking' else 
'Case ' + convert(varchar,convert(decimal(18,2),casenum)) end as CaseDescrip,

deslisttfassymat.Param1Value,deslisttfassymat.Param2Value,deslisttfassymat.Param3Value,deslisttfassymat.Param4Value,
deslisttfassymat.Param5Value,deslisttfassymat.Param6Value,deslisttfassymat.Param7Value,

	deslisttfassymat.CSDia,deslisttfassymat.InnerDia,deslisttfassymat.OuterDia,deslisttfassymat.Thk,
deslisttfassymat.Lo,deslisttfassymat.Li,deslisttfassymat.Bo,deslisttfassymat.Bi,deslisttfassymat.Wid,deslisttfassymat.L1,deslisttfassymat.L2,
deslisttfassymat.Drg,deslisttfassymat.DescripFinal,deslisttfassymat.Descrip as AssyMatDescrip,



isnull(tfdespacklist.qtytanking,deslisttfassymat.QtyTanking) as QtyTanking, 
isnull(tfdespacklist.qtytransport,deslisttfassymat.QtyTransport) as QtyTransport,
isnull(tfdespacklist.QtyErection,deslisttfassymat.QtyErection) as QtyErection,

deslisttfassymat.Remark,
isnull(tfdespacklist.appendindent,'') + 
case when isnull(deslisttfassymat.tfpartdefid,0)>0 or isnull(deslisttfassymat.hwdia,0)>0 then 
	case when len(deslisttfassymat.parentcasecode)>0 then  deslisttfassymat.PartDescrip+ ' for '+deslisttfassymat.Descrip   else deslisttfassymat.PartDescrip  end
else deslisttfassymat.Descrip end 
+ case when len(tfdespacklist.packnote)>0 then ' ' + tfdespacklist.packnote else '' end as Descrip
,
tfdespacklist.casenum,
tfdespacklist.itemnum,
deslisttfassymat.itemnum as BOMNum,
tfdespacklist.Qty

from deslisttfassymat()
left join tfdespacklist on tfdespacklist.tfdesassymatid = deslisttfassymat.tfdesassymatid
)
























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListTFAssyMatItem]'
GO







CREATE function [dbo].[desListTFAssyMatItem]()
returns table
	return (


select deslisttfassymat.pidunitid, 
tfdami.tfdesassymatitemid,
deslisttfassymat.TFDesAssyMatID,deslisttfassymat.DefCode,deslisttfassymat.TFPartDefID,
deslisttfassymat.TFPartDefCodeCalc,deslisttfassymat.TFPartDefCode,deslisttfassymat.TypeNum,
deslisttfassymat.hwmaterialdescrip,

IsParent,deslisttfassymat.packlistnote,deslisttfassymat.isweldedhw,

deslisttfassymat.HWMainElemType,deslisttfassymat.HWDia,deslisttfassymat.HWLen,
deslisttfassymat.HWMainElem,deslisttfassymat.HWSize,
deslisttfassymat.PWNum,deslisttfassymat.SWNum,deslisttfassymat.LockNutNum,deslisttfassymat.FullNutNum,
deslisttfassymat.TFPartDefCatID,deslisttfassymat.Descrip as CatDescrip,deslisttfassymat.TFPartDefClass,deslisttfassymat.TFPartDefClassName,
deslisttfassymat.Param1Name,deslisttfassymat.Param2Name,deslisttfassymat.Param3Name,deslisttfassymat.Param4Name,
deslisttfassymat.Param5Name,deslisttfassymat.Param6Name,deslisttfassymat.Param7Name,

deslisttfassymat.Param1Value,deslisttfassymat.Param2Value,deslisttfassymat.Param3Value,deslisttfassymat.Param4Value,
deslisttfassymat.Param5Value,deslisttfassymat.Param6Value,deslisttfassymat.Param7Value,

	deslisttfassymat.CSDia,deslisttfassymat.InnerDia,deslisttfassymat.OuterDia,deslisttfassymat.Thk,
deslisttfassymat.Lo,deslisttfassymat.Li,deslisttfassymat.Bo,deslisttfassymat.Bi,deslisttfassymat.Wid,deslisttfassymat.L1,deslisttfassymat.L2,
deslisttfassymat.Drg,deslisttfassymat.DescripFinal,deslisttfassymat.Descrip as AssyMatDescrip,

isnull(ili.initialcode,'')+ '-'+isnull(ili.subcatname,'Not Found') as subcat,
ili.itemid,ili.subcatid,isnull(ili.subcatname,'Not Found') as subcatname,

isnull(ili.Itemcode,'Not Found') as ItemCode,
isnull(ili.ItemName,tfdami.description) as ItemName,
tfdami.QtyTanking,
tfdami.QtyTransport,
tfdami.QtyErection


from tfdesassymatitem as tfdami
left join invlistitems() as ili on tfdami.itemid = ili.itemid
inner join deslisttfassymat() on tfdami.tfdesassymatid = deslisttfassymat.tfdesassymatid


)
























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[plnListPIDU]'
GO





CREATE        function [dbo].[plnListPIDU]()
returns table
	return (


select 

pidunit.pidunitid, FileNum, FileVol,IsCompleted, orderdate as dated, lastupdated,
startupdefid,pidunit.templatefilename,descrip + '-' + customer as pidinfo,pidunit.descrip as woinfo,
      Customer, Descrip, FileNumComp,    
      OrderDate,DesignDate,
      Remarks


from pidunit



)


























































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DepsMat]'
GO
CREATE TABLE [dbo].[DepsMat]
(
[MatDepID] [int] NOT NULL,
[CampusID] [int] NULL,
[DepCode] [nvarchar] (50) NULL,
[DepName] [nvarchar] (50) NULL,
[LabName] [varchar] (50) NULL,
[AcceptsDoc] [bit] NULL,
[IsStore] [bit] NULL,
[GivesReq] [bit] NULL,
[AcceptsWO] [bit] NULL,
[IsShop] [bit] NULL,
[AcceptsReq] [bit] NULL,
[LastVouchNum] [int] NULL CONSTRAINT [DF_DepsMat_LastVouchNum] DEFAULT ((0)),
[HasNC] [bit] NULL,
[IncGroup] [varchar] (100) NULL,
[SeqMult] [int] NULL,
[SeqOffset] [int] NULL,
[DepID] [int] NULL,
[OldShop] [bit] NULL,
[HasLab] [bit] NULL,
[UnitNum] [int] NULL,
[TestGroup] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DepsMat] on [dbo].[DepsMat]'
GO
ALTER TABLE [dbo].[DepsMat] ADD CONSTRAINT [PK_DepsMat] PRIMARY KEY CLUSTERED  ([MatDepID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListPIDCtlBOM]'
GO




CREATE   function [dbo].[desListPIDCtlBOM]()
returns table
	return (

select itemvmsbom.ItemVMSBOMID,ItemVMSBOM.ItemVMSID, ItemVMSBOM.ChildItemVMSID,
ili.itemid, ili.subcatid, pidctl.pidunitid,pidctl.ctlitemid,
dbo.fncstwriteas(itemvms.itemvmsid) as Stds, pidctl.location,
itemvms.Packing,pidctl.cp,

ctlcat.ctlcat,

ili.ItemCode + ' - ' + itemvms.specWrite as ItemCode,
ili.Itemname,
itemvms.KanSpecs,
itemvms.Make,
itemvms.SuppSpec,
ItemVMSBom.Qty*case when isnumeric(pidctl.Qty)=1 then pidctl.qty else 0 end as Qty

from pidctl
	inner join ctlitems on pidctl.ctlitemid = ctlitems.ctlitemid
	left join ctlcat on ctlitems.ctlcatid = ctlitems.ctlcatid
	inner join itemvmsBOM on ctlitems.itemvmsid = itemvmsBOM.itemvmsid
	inner join itemVMS on itemVMSBom.ChildItemVMSID = itemvms.ItemVMSID
	inner join invlistitems() as ili on itemvms.itemid = ili.itemid





)









































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListItemVMSBOM]'
GO







CREATE function [dbo].[desListItemVMSBOM]()
returns table
	return (


select itemvmsbom.ItemVMSBOMID,ItemVMSBOM.ItemVMSID, ItemVMSBOM.ChildItemVMSID,

ili.itemid, 
ili.ItemCode,
ili.ItemName,

ctlitems.ctlitemid,
case when ili.subcatid is null then ilis.subcatid else ili.subcatid end as subcatid,

(select top 1 ctlcatid from ctlitems where ctlitems.itemvmsid = itemvmsbom.itemvmsid and ctlcatid is not null) as ctlcatid,
(select top 1 ctlcat from deslistctlitems() where deslistctlitems.itemvmsid = itemvmsbom.itemvmsid and ctlcatid is not null) as ctlcat,

case when isnull(itemvms.specmatspec,'')<>'' then itemvms.specmatspec
	when isnull(ili.matspec,'')<>'' then ili.matspec
	else ili.ItemName end as Spec,
itemvms.Make,
itemvms.KanSpecs,itemvms.SuppSpec,itemvms.Packing,
dbo.fncstwriteas(itemvms.itemvmsid) as Stds,

case when ili.itemid is null then 'Sub Category' else 'Item' end as BOMType,
case when ili.itemid is null then ilis.initialcode else ili.ItemCode end + ' - ' + itemvms.specWrite as Code,
case when ili.itemid is null then ilis.subcatname else ili.ItemName end as [Name],
itemvmsbom.QtyFormula,
ItemVMSBom.Qty




from ItemVMSBom
inner join itemVMS on itemVMSBom.ChildItemVMSID = itemvms.ItemVMSID
left join invlistitems() as ili on itemvms.itemid = ili.itemid
left join invlistitemsubcats() as ilis on itemvms.subcatid = ilis.subcatid
left join ctlitems on ctlitems.itemvmsid = itemvmsbom.itemvmsid
)






















































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListPIDUnit]'
GO




CREATE             function [dbo].[desListPIDUnit]()
returns table
	return (


select 

pidunit.pidunitid, FileNum, FileVol,IsCompleted, orderdate as dated, lastupdated,
startupdefacid,startupdefid,pidunit.hasassymatlist,pidunit.templatefilename,
[HWMaterial], [HWMaterialDescrip], [HWMaterial2], [HWMaterial2Descrip], [HWMaterial2MaxDia],
PackListNote, mtgabomsort,
mfgtypecode,pidunittype, wdggroupnum,coregroupnum,tankgroupnum,
pidinfo,pidunit.descrip as woinfo,pidunit.wonum,
      Customer, Descrip, FileNumComp,    
      OrderDate,DesignDate,
      Remarks


from pidunit



)

























































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListPIDUParams]'
GO






CREATE  function [dbo].[desListPIDUParams]()
returns table
return (


select DesParams.IsNumber,

piduparams.paramtag, desparams.sortindex,
case when isnull(isdbcadparam,0)=1 then 0 else 1 end as isdespiduparam,
isdbcadparam,

desparams.datatype, desparams.ridestableid, 
dlpu.customer,desparams.destablecolid,dlpu.descrip,
desparams.defaultvalue,0 as iscalculated,'' as formula,
PIDUParams.PIDUParamID,dlpu.PIDUnitid,DesParams.DesParamID,

ParamGroup, 
piduparams.valuedescrip,

ParamCode, ParamName, PIDUParams.ParamValue

from DesParams
cross join deslistpidunit() as dlpu
left join piduParams on piduparams.desparamid = desparams.desparamid and piduparams.pidunitid = dlpu.pidunitid








)


























































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListProDocu]'
GO



CREATE              function [dbo].[desListProDocu]()
returns table
	return (


select 

prodocuid, desdocs.desdocid,prodocu.pidunitid, DesDocs.desdocGrpID,serialnum, prodocu.hascollec,
prodocu.pdfsource,prodocu.actsource,prodocu.revnum,prodocu.revdate,prodocu.hasBOM,
desdocs.displayorder, desdocs.doctextxml,prodocu.topleveldoc,dlpu.mfgtypecode,
prodocu.refdrg, desdocs.ischart, prodocu.docname, prodocu.suffix, prodocu.prefix, prodocu.bommaxnum,
prodocu.docempid, prodocu.reportstatus,prodocu.reportremark,prodocu.statusgroupnum,
desdocs.autotypecode, desdocs.displayform, desdocs.genfunc, desdocs.typecode,prodocu.docdistricodeid,

convert(int,isnull(case when prodocu.topleveldoc is null then desdocs.toplevelBOM else prodocu.topleveldoc end,0)) as topLevelBOM,
prodocu.issuedon, prodocu.planon,isnull(prodocu.blanklinea,0) as blanklinea,isnull(prodocu.blanklineb,0) as blanklineb,

dlpu.filenumcomp,dlpu.filenum, prodocu.drgnum,


case when issuedon is null then 0 else 1 end as iscompleted,

case when prodocu.issuedon is null then 'Plan' + 
	case when prodocu.planon is null then '' else ' ' + convert(varchar,prodocu.planon,106) end
else convert(varchar,prodocu.issuedon,106) end as issuedonsct,

prodocu.drgon, prodocu.chkon, prodocu.appon,desdocs.doctext,desdocgrp.desdocgrp,
prodocu.remark,pdfownerpass,pdfuserpass,prodocu.prepbyid, prodocu.prepbyid2, prodocu.chkbyid, prodocu.appbyid,
case when coalesce(desdocs.inassemblyext,desdocgrp.inassemblyext,0)=1 and isnull(dlpu.hasassymatlist,0)=1 then 1 else 0 end as hideassemblymat,


dlpu.customer,pidinfo,dlpu.woinfo,

convert(varchar,desdocs.desdocGrpID) + '.' + convert(varchar,prodocu.serialnum)
as Serial,

--dbo.fncdrgnum(filenum, drgnum, desdocs.desdocgrpid, wdggroupnum, coregroupnum, tankgroupnum, refdrg) as Drawing,
case when len(isnull(Refdrg,''))>0 then refdrg else drgnum end as Drawing,

 case when isnull(revNUM,'')<>'' then ' Rev ' + convert(varchar,isnull(revnum,0)) else '' end + case when revdate is not null then ' Dt. ' + convert(varchar,revdate,106) else '' end  as Revision,

upper(isnull(Prefix,'') + ' ' + isnull(DocName,'') + ' ' + isnull(Suffix,'')) as Document,

	
DistriDescrip,

NumSheets, 


case when issuedon is not null then convert(varchar,issuedon,106) + ' ' 
when appon is not null then 'Compl. on ' + convert(varchar,appon,106) + ' '
else '' end  

+ isnull(prodocu.remark,'')
as Remarks


from ProDocu 
	inner join desdocs on prodocu.desdocid = desdocs.desdocid
	inner join desdocgrp on desdocs.desdocGrpID = desdocgrp.desdocGrpID
	inner join deslistpidunit() as dlpu on prodocu.pidunitid = dlpu.pidunitid
	
left join docdistricode on prodocu.docdistricodeid = docdistricode.docdistricodeid
	
)
































































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListDrgItemCalc]'
GO






















CREATE function [dbo].[desListDrgItemCalc]()
returns table
	return (


select DrgItems.DrgItemid, DrgItems.ProDocuID, dlpd.pidunitid, 
drgitems.refdrgitemid,cnctypes.inattachmatlist, 
case when dr2.drgitemid is null then drgitems.excludecnc else dr2.excludecnc end as excludecnc,
drgitemcalc.ChildDrgItemID,drgitemcalc.drgitemcalcID,stddrg.stddrgid,dlpd.desdocgrpid,dlpd.desdocgrp,
isnull(ili.bomsectiontypecode,0) as bomsectiontypecode, 
ili.initialcode,
dr2.specification as specparent, dr2.description as descripparent,
isnull(Drgitems.haslegend,0) as haslegend, 
drgitemcalc.legend, drgitemcalc.refidlist,
case when drgitems.drgitemid = dr2.drgitemid then 'PART' + convert(varchar,drgitems.drgitemid)
else 'PARTBOM' + convert(varchar,dr2.drgitemid) end as DrgItemPartID,
case when isnull(ili.bomsectiontypecode,0)=1 then case when dr2.hasnojoints=1 then dbo.fncmax(drgitemcalc.width,drgitemcalc.outerdia) else null end else null end as njwidth,
case when isnull(ili.bomsectiontypecode,0)=1 then case when dr2.hasnojoints=1 then dbo.fncmax(drgitemcalc.[length],drgitemcalc.outerdia) else null end else null end as njlength,
case when isnull(ili.bomsectiontypecode,0)=2 then drgitemcalc.[length] else null end as sectionlen,
 case when drgitemcalc.width2=0 then '-' else 
	case when drgitemcalc.[length]-drgitemcalc.length2 = drgitemcalc.width-drgitemcalc.width2 then 	convert(varchar,convert(Decimal(18,1),(drgitemcalc.Width-drgitemcalc.Width2)/2),0) else convert(varchar,convert(Decimal(18,1),(drgitemcalc.[length]-drgitemcalc.length2)/2),0) + ',' + convert(varchar,convert(decimal(18,1),(drgitemcalc.Width-drgitemcalc.Width2)/2),0) end
end as Wid,

cnctypes.cnctypename,cnctypes.cnctypeid, ili.ishardware, cnctypes.titleqc,

dlpd.pidinfo + '           BILL OF MATERIAL' + char(10) + char(13)+
dlpd.drawing + '          -' + dlpd.[document] as bominfo,

dr2.stddrgid as refstddrgid,
ili.schedname,ili.itemschedid,
dr2.prodocuid as refprodocuid,

dbo.fncstringnum(drgitems.itemnum,dlpd.bommaxnum) as ItemNum,

drgitems.iscollection,

dlpd2.pidunitid as refpidunitid,

isnull(drgitems.descripchartaddl,'') + case when isnull(drgitems.descripchartaddl,'')='' then '' else ' ' end +
drgitemcalc.descripchart as DescripChart,
dr2.nocommoncut,dr2.gaskettypecode,dr2.iswelded,

isnull(ili.isgasket,0) as isgasket,isnull(dr2.itemcollectypecode,0) as itemcollectypecode,

case when isnull(dr2.itemcollectypecode,0)=1 then
dbo.fncGetHWType(ili.pxmlc,ili.pvaluec) else '' end as element, ili.pvaluec,

case when isnull(drgitems.qty,0)>0 then drgitemcalc.qty/drgitems.qty else 0 end as bomqty,

convert(varchar,drgitems.drgitemid) + ':' + isnull(convert(varchar,dr2.drgitemid),'') as hwctcode,

dlpd.woinfo, ili.subcatid, ili.itemid, dlpd.hascollec, 
ili.perwastage, ili.itemname, ili.subcatname,  ili.itemcode,


dr2.drgitemid as partdrgitemid,		--for hardware crosstab (no select distinct)

dr2.matsection,drgitemcalc.length,drgitemcalc.length2,drgitemcalc.width,drgitemcalc.width2,drgitemcalc.innerdia,
drgitemcalc.outerdia,dr2.hasnojoints,

isnull(dr2.isboughtout,0) as IsBoughtOut,
drgitemcalc.cncdrgnew,drgitemcalc.cncdrgnew2,drgitemcalc.cncdrgnew3,drgitemcalc.cncdrgnew4,
case when len(drgitemcalc.cncdrgnew2)>0 then drgitemcalc.cncdrgnew2 else dr2.cncdrg2 end as cncdrg2,
case when len(drgitemcalc.cncdrgnew3)>0 then drgitemcalc.cncdrgnew3 else dr2.cncdrg3 end as cncdrg3,
case when len(drgitemcalc.cncdrgnew4)>0 then drgitemcalc.cncdrgnew4 else dr2.cncdrg4 end as cncdrg4,

dr2.Category,dr2.SubCategory,

case when len(isnull(drgitemcalc.cncdrgnew,dr2.CNCDrg))=0
then 'Not OK' else 'OK' end as CNCStatus,

case when len(drgitemcalc.cncdrgnew)>0 then drgitemcalc.cncdrgnew else dr2.cncdrg end as CNCDrg,



--case when drgitembom.itemid is null then
		case when dlpd2.prodocuid is null then case when isnull(sd2.isghost,0)=0 then isnull(sd2.completenum,'') end
		else isnull(dlpd2.drawing,'') end
			+ ' - ' + isnull(dr2.itemnum,'') +
	case when isnull(dr2.isboughtout,0)=1 then ' (Bought out)' else '' end
--else ili.itemcode end
as PartNum,


case when isnull(Dr2.drgitemid,0)=isnull(drgitems.drgitemid,0) then '' else 
drgitemcalc.reference end as Reference,

drgitemcalc.Description,

drgitemcalc.Thk,

drgitemcalc.Specification,

case when len(dr2.Material)=0 then 
			case when len(ili.drgbomname)=0 then ili.subcatname else ili.drgbomname end 
else dr2.Material end as Material,

drgitemcalc.Qty,

case when isnull(Dr2.seedetail,0)  =1 
then 'SEE DETAIL' else '' end +dr2.Remark as Remark,

drgitemcalc.Weight

from DrgItemCalc
inner join drgitems on drgitemcalc.drgitemid = drgitems.drgitemid
inner join deslistprodocu() as dlpd on drgitems.prodocuid = dlpd.prodocuid
inner join drgitems as dr2 on drgitemcalc.childdrgitemid = dr2.drgitemid
left join deslistprodocu() as dlpd2 on dr2.prodocuid = dlpd2.prodocuid
left join stddrg on drgitems.stddrgid = stddrg.stddrgid
left join stddrg as sd2 on dr2.stddrgid = sd2.stddrgid
left join invlistitems() as ili on drgitemcalc.itemid= ili.itemid
left join cnctypes on isnull(drgitemcalc.cnctypeidnew,ili.cnctypeid)= cnctypes.cnctypeid

--TODO: provision for standard assembly parts
where not (isnull(dlpd.hideassemblymat,0)=1 and (isnull(cnctypes.isgasket,0)=1 or isnull(cnctypes.ishardware,0)=1))

)









































































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[camListReqItems]'
GO










CREATE function [dbo].[camListReqItems]()
returns table
	return (


select tfnestreq.tfnestreqid, tfnestreq.pidunitid, tfnestreq.iscompleted,

dldip.DrgItemid, ProDocuID, ChildDrgItemID, drgitemcalcID, stddrgid, 
tfnestreq.reqdate,
dldip.desdocgrp,dldip.nocommoncut,dldip.excludecnc,

DrgItemPartID,IsBoughtOut,CNCStatus,
CNCDrg,cncdrg2,cncdrg3,cncdrg4,
tlts.woinfo as reqinfo,

Category,
SubCategory,

PartNum,

Reference,

Description,
Specification,
Thk,

--convert(int,(select sum(qty) from tfnestitems where tfnestreq.tfnestreqid = tfnestitems.tfnestreqid and dldip.drgitempartid = tfnestitems.drgitempartid)) as qtydone,

convert(int,case when isnull(tfnestreq.qty,0)>0 then tfnestreq.qty else 1 end*dldip.Qty) as Qty,

dldip.Remark,
Weight

from tfnestreq
inner join deslistpidunit() as tlts on tfnestreq.pidunitid = tlts.pidunitid
inner join deslistDrgItemcalc() as dldip on dldip.pidunitid = tlts.pidunitid and dldip.desdocgrp = tfnestreq.desdocgrp and dldip.cnctypeid = tfnestreq.cnctypeid




)



































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListDrgItems]'
GO



CREATE function [dbo].[desListDrgItems]()
returns table
	return (


select DrgItems.DrgItemid, 
itemscheds.schedname,
stddrg.StdDrgID,  dlpd.ProDocuID,drgitems.itemnum1,drgitems.itemnum2,
dr2.stddrgid as refstddrgid, dr2.prodocuid as refprodocuid,pd2.pidunitid as refpidunitid,
case when isnull(drgitems.qty,0)=0 then 1 else drgitems.qty end as wtqty,

drgitems.haslegend,
drgitems.itemid, drgitems.itemcollectypecode,drgitems.iswelded,drgitems.gaskettypecode,
items.subcatid, itemsubcats.bomsectiontypecode, items.bomthk, 
cnctypes.cnctypeid, cnctypes.cnctypename, cnctypes.isgasket,
dlpd.pidinfo + '           BILL OF MATERIAL' + char(10) + char(13)+
dlpd.drgnum + '          -' + dlpd.[document] as bominfo,dlpd.drawing,

isnull(case when stddrg.stddrgid is null then dlpd.hascollec else stddrg.hascollec end,0) as hascollec,
case when stddrg.stddrgid is null then 0 else 1 end as isstd, stddrg.groupnum,

case when dlpd.prodocuid is null then 0 else
case when isnull(dlpd.hascollec,0)=0 or isnull(drgitems.iscollection,0)=1 then 1 else 0 end end as hascalc,

dlpd.pidunitid,dlpd.hasbom, dlpd.bommaxnum, dlpd.drgnum,
DrgItems.MatSection,DrgItems.CNCDrg,DrgItems.Category,DrgItems.SubCategory,

drgitems.InnerDia, drgitems.Length2, drgitems.Length, drgitems.OuterDia, 
drgitems.Width2, drgitems.Width, drgitems.descripchart,drgitems.descripchartaddl,

drgitems.rectreducexml, drgitems.roundreducexml, drgitems.trianglereducexml, drgitems.radiusreducexml,

drgitems.paramreqxml, drgitems.paramvaluexml, itemsubcats.density, Items.WtPerMtr,
drgitems.InnerDiaParamID, drgitems.Length2ParamID, drgitems.LengthParamID, drgitems.OuterDiaParamID, 
drgitems.Width2ParamID, drgitems.WidthParamID, drgitems.ThkParamID, drgitems.ThreadParamId,

DrgItems.RefDrgItemID,

isnull(DrgItems.IsCollection,0) as iscollection,
stddrg.completenum + ' - ' + stddrg.DrgName as stddrg, drgitems.isdeleted,

isnull(dlpd.drgnum,stddrg.completenum) as Doc,
isnull(dlpd.filenum,' STD') as FileNum,

dbo.fncstringnum(drgitems.itemnum,isnull(dlpd.bommaxnum,stddrg.bommaxnum)) as ItemNum,

		
DrgItems.Thk,
case when isnull(DrgItems.isdeleted,0)=1 then '*Deleted*' else '' end+
case when dlpd.prodocuid is not null then dlpd.drgnum + ' - ' + DrgItems.itemnum
else stddrg.completenum + ' - ' + DrgItems.itemnum end as Item,

DrgItems.Description, 

replace(DrgItems.Specification,'- 901','') as Specification, 

coalesce(drgitems.material, items.drgbomname, itemsubcats.drgbomname, itemsubcats.subcatname) as Material,


DrgItems.Qty, 

case when isnull(drgitems.seedetail,0)=1 then 'SEE DETAIL' else '' end +
isnull(drgItems.Remark,'') as Remark, 

DrgItems.Weight


from DrgItems
left join deslistprodocu() as dlpd on drgitems.prodocuid = dlpd.prodocuid
left join stddrg on drgItems.stddrgid = stddrg.stddrgid
left join drgitems as dr2 on drgitems.refdrgitemid = dr2.drgitemid
left join prodocu as pd2 on dr2.prodocuid = pd2.prodocuid
left join items on drgitems.itemid = items.itemid
left join itemsubcats on items.subcatid = itemsubcats.subcatid
left join itemscheds on itemsubcats.itemschedid = itemscheds.itemschedid
left join cnctypes on itemsubcats.cnctypeid = cnctypes.cnctypeid

)

















































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListDrgItemBOM]'
GO
















CREATE function [dbo].[desListDrgItemBOM]()
returns table
	return (


select drgitembom.ChildDrgItemID, drgItemBOMID,drgitemBOM.DrgItemid, 
drp.ProDocuID, drp.stddrgid, drc.stddrgid as refstddrgid,drc.prodocuid as refprodocuid,
drc.MatSection,drc.Thk,Drc.Length,Drc.Width,dlpd.pidunitid,

case when isnull(drc.qty,0)=0 then 1 else drc.qty end as wtqty,
case when dlpd.hascollec=1 then drp.itemnum else 'Qty' end as listpivot,
case when dlpd.hascollec=1 then 'Qty'+ case when isnull(drp.itemnum,'')='901' then '' else char(10) + char(13)+drp.itemnum end else 'Qty'  end as listpivotcaption,
case when drc.drgitemid is null then 'PART' + convert(varchar,drp.drgitemid)
else 'PARTBOM' + convert(varchar,drc.drgitemid) end as DrgItemPartID,
drc.drgitemid as partdrgitemid,		--for hardware crosstab (no select distinct)
dbo.fncstringnum(drc.itemnum,isnull(dlpd.bommaxnum,0)) as bomitemnum,
dlpd.pidinfo + '           BILL OF MATERIAL' + char(10) + char(13)+
dlpd.drawing + '          -' + dlpd.[document] as bominfo,

drgitembom.cncdrg,items.itemcode, drgitembom.legend, drc.haslegend,
items.itemid, itemsubcats.subcatid, items.wtperno, items.itemname, items.bommatsection,
itemsubcats.pvaluea, itemsubcats.pvalueb, itemsubcats.pvaluec, itemsubcats.pvalued, 
itemsubcats.pvaluee, items.xvalue, items.yvalue, items.zvalue, items.svalue, items.pvalue,
drc.paramreqxml, drc.paramvaluexml,

drgitembom.specbom,drgitembom.descripbom,

case when isnull(drc.qty,0)>0 then isnull(drc.weight,0)/drc.qty else drc.weight end as wtpu,
Drc.Category,Drc.SubCategory,Drc.RefDrgItemID,Drp.IsCollection,

Drc.ItemNum, 
case when isnull(drc.isdeleted,0)=1 then '*Deleted*' else '' end+
Drc.Description as Description, 

Drc.Specification, 
Drc.Material, DrgItemBOM.Qty, 

DrgItemBom.QtyParamID,

Drc.Remark, case when drc.drgitemid is null then drgitembom.weight else drc.weight end as weight


from DrgItemBOM
	inner join drgitems as drp on drgitembom.drgitemid = drp.drgitemid
	left join deslistDrgItems() as drc on drgitemBOM.childdrgitemid=drc.drgitemid
	left join deslistprodocu() as dlpd on drp.prodocuid = dlpd.prodocuid
	left join items on drgitembom.itemid = items.itemid
	left join itemsubcats on items.subcatid = itemsubcats.subcatid

)




























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[camListReq]'
GO




CREATE function [dbo].[camListReq]()
returns table
	return (


select tfnestreq.tfnestreqid, 
tfnestreq.drgitemid,tlts.pidunitid, tfnestreq.cnctypeid,
tfnestreq.iscompleted, 

Customer,'' as Rating,
woinfo as ReqInfo, WOInfo,
tfnestreq.DesDocGrp, 

deslistdrgitems.Item, tfnestreq.Qty, 

tfnestreq.ReqDate,

tfnestreq.WorkGroup,

case when isnull(tfnestreq.IsCompleted,0)=0 then 'Incomplete' else 'Complete' end as Status,

tfnestreq.Remark

from tfnestreq
inner join deslistpidunit() as tlts on tfnestreq.pidunitid = tlts.pidunitid
left join deslistdrgitems() on tfnestreq.drgitemid = deslistdrgitems.drgitemid

)































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[camListNestItems]'
GO








CREATE function [dbo].[camListNestItems]()
returns table
	return (


select tfnestitems.tfnestitemid, tfnestitems.tfnestreqid, tfnestitems.tfnestid,
 camlistreq.iscompleted,
tfnestitems.snum,
tfnest.thk, camlistreq.reqdate,
camlistreq.DrgItemid, camlistreq.pidunitid, 

camlistreq.desdocgrp,
tfnestitems.nocommoncut,
tfnestitems.CNCDrg,
camlistreq.reqinfo,
tfnestitems.PartNum,
tfnestitems.Reference,
tfnestitems.Description,
--flri.qty - (select sum(qty) from tfnestitems as tfni2 where tfni2.tfnestreqid = tfnestitems.tfnestreqid and tfni2.drgitempartid = tfnestitems.drgitempartid) as Bal,
tfnestitems.Specification,
tfnestitems.QtyReq,
tfnestitems.Qty,
tfnestitems.QtyNested

from tfnestitems
inner join tfnest on tfnestitems.tfnestid = tfnest.tfnestid
inner join camlistreq() on tfnestitems.tfnestreqid = camlistreq.tfnestreqid
--inner join camlistreqitems() as flri on tfnestitems.tfnestreqid = flri.tfnestreqid and tfnestitems.drgitempartid=flri.drgitempartid


)





































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListPIDUnitTot]'
GO
















CREATE  function [dbo].[desListPIDUnitTot]()
returns table
	return (


select * from deslistpidunit()

)



























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListProDocuEdit]'
GO


CREATE         function [dbo].[desListProDocuEdit]()
returns table
	return (


select desdocs.doctext,
prodocu.idvalue,prodocu.idfield,desdocs.distritypecode,deslistpidunittot.mfgtypecode,
prodocuid, desdocs.desdocid,prodocu.pidunitid, desdocs.desdocGrpID, 
 prodocu.hasbom, consautolist,groupinsideor,
desdocs.ischart,desdocs.numsheetsformula,indexformula,
typecode,wdgname1,wdgname2,termnum,
desdocs.displayorder,
desdocs.doctextxml,

prodocu.docdistricodeid,
SerialNum, Prefix, DocName, Suffix, 
DistriCode,
DistriDescrip,

DrgNum, 
RevNum, RevDate, RefDrg, 
NumSheets,
IssuedOn

from ProDocu 
	inner join desdocs on prodocu.desdocid = desdocs.desdocid
	inner join deslistpidunittot() on prodocu.pidunitid = deslistpidunittot.pidunitid
	left join docdistricode on prodocu.docdistricodeid = docdistricode.docdistricodeid
	
where isnull(woinfo,'')<>''

)




































































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListDocDistriCodes]'
GO















CREATE  function [dbo].[desListDocDistriCodes]()
returns table
	return (


select docdistricodeid,depsmat.matdepid, 
 MfgTypeCode, DocTypeCode, 
DepName, DistriCode,DistriDescrip

from docdistricode
inner join depsmat on docdistricode.matdepid = depsmat.matdepid


)



























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[desListPIDCtl]'
GO







CREATE          function [dbo].[desListPIDCtl]()
returns table
	return (


select 

pidctl.pidunitid,  dlp.descrip,dlc.lugtype,pidctl.lugtypetext,pidctl.lugqty,
iscompleted,pidinfo,pidctl.pidctlid,dlc.ctlitemid,
descripprefix,descripsuffix,dlc.itemid, dlc.subcatid,

PIDCTL.terminalnumxml,pidctl.compimagewd, dlc.haswd, pidctl.legend,

isnull(dlc.itemvmsid,0) as itemvmsid,  DontPrintInMatList,
dlc.MtgMB,dlc.MtgCP,upper(pidctl.location) as Location,
dlc.MtgMBID,dlc.MtgCPID,pidctl.qty,pidctl.qtynet,

pidctlpanel.panelname as Loc,
case when isnull(pidctlpanel.paneltype,0)=2 then mtgcpid else mtgmbid end as mtgid,
dlc.ganame, pidctl.gause, dlc.garating, pidctl.legendsga,qtynum, dlc.gamakes,

Customer,
dlp.Filenum, dlp.woinfo,dlc.CtlCat, 

dlc.ItemCode,

dlc.Item, 

isnull(pidctl.descripprefix,'') + dlc.Spec + isnull(pidctl.descripsuffix,'')
as Spec,

dlc.Make, 

dlc.SuppSpec,  

pidctl.Legends,

ctlmtg.mtgcode as Mtg,

pidctl.QtyPrint, dlc.Price, isnull(pidctl.qtynet,0)*dlc.price as TotalCost


from pidctl
	inner join deslistpidunit() as dlp on pidctl.pidunitid=dlp.pidunitid
	inner join deslistctlitems() as dlc on pidctl.ctlitemid = dlc.ctlitemid
	left join pidctlpanel on pidctl.pidunitid = pidctlpanel.pidunitid and pidctl.location = pidctlpanel.panelcode
	left join ctlmtg on ctlmtg.ctlmtgid = case when isnull(pidctlpanel.paneltype,0)=2 then mtgcpid else mtgmbid end

)
























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ctsListPIDCtlMtgItem]'
GO











CREATE function [dbo].[ctsListPIDCtlMtgItem]()
returns table
	return (


select ctlmtg.ctlmtgid, mtgcode, ili.itemid,
	pidunitid,loc,deslistpidctl.location,

	ctlmtg.Descrip, ili.ItemCode, ili.ItemName, sum(deslistpidctl.qty*ctlmtgitem.qty) as qty









from deslistpidctl()
	inner join ctlmtg on deslistpidctl.mtgid = ctlmtg.ctlmtgid
	left join ctlmtgitem on ctlmtg.ctlmtgid = ctlmtgitem.ctlmtgid
	left join invlistitems() as ili on ctlmtgitem.itemid = ili.itemid

where ili.itemid is not null

group by
ctlmtg.ctlmtgid, mtgcode, ili.itemid,
	pidunitid,loc,deslistpidctl.location,

	ctlmtg.Descrip, ili.ItemCode, ili.ItemName
	
)




























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[ctsListPIDCtlItems]'
GO


CREATE  function [dbo].[ctsListPIDCtlItems]()
returns table
	return (


select pidctlitem.pidctlitemid, deslistpidctl.pidunitid, ili.itemid,ctlitemid,
	deslistpidctl.location,filenum,pidinfo,deslistpidctl.loc,
	deslistpidctl.legend, ili.itemcode, ili.itemname , pidctlitem.itemtext,
	
	isnull(ili.itemcode,'Text') as CtlItemCode,
	isnull(ili.itemname,pidctlitem.itemtext) as CtlItemText,
	pidctlitem.qty



from pidctlitem
	inner join deslistpidctl() on pidctlitem.pidctlid = deslistpidctl.pidctlid
	left join invlistitems() as ili on pidctlitem.itemid = ili.itemid
	
)





























































































GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[fncDrgNum]'
GO













CREATE  function [dbo].[fncDrgNum](@filenum varchar(1000), @drgnum int, @desdocgrpid int, @wdggrpnum int, @coregrpnum int, @tankgrpnum int, @refdrg varchar(1000))
returns varchar(1000)
begin
	declare @tempname varchar(1000)
	
	set @tempname =
	case when @drgnum>0 then
	case when @desdocGrpID=1 then @filenum + ' / ' + convert(varchar,@drgnum)
		when @desdocGrpID=3 then @filenum + case when @wdggrpnum>0 then '/ ' + convert(varchar,@wdggrpnum) else '' end + '/ ' + convert(varchar,@drgnum)
		when @desdocGrpID=4 then @filenum + case when @coregrpnum>0 then '/ ' + convert(varchar,@coregrpnum) else '' end + '/ ' + convert(varchar,@drgnum)
		when @desdocGrpID=5 then @filenum + case when @tankgrpnum>0 then '/ ' + convert(varchar,@tankgrpnum) else '' end + '/ ' + convert(varchar,@drgnum) end
	when isnull(@refdrg,'')<>'' then @refdrg
	else '' end 


	return @tempname
end

















GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[CodeWords]'
GO
CREATE TABLE [dbo].[CodeWords]
(
[CodeWordID] [int] NOT NULL IDENTITY(1, 1),
[CodeClass] [varchar] (50) NULL,
[CodeType] [varchar] (50) NULL,
[CodeWord] [varchar] (50) NULL,
[DescripShort] [varchar] (1000) NULL,
[DescripLong] [varchar] (8000) NULL,
[Tag] [varchar] (50) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_CodeWords] on [dbo].[CodeWords]'
GO
ALTER TABLE [dbo].[CodeWords] ADD CONSTRAINT [PK_CodeWords] PRIMARY KEY CLUSTERED  ([CodeWordID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_CodeWords] on [dbo].[CodeWords]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CodeWords] ON [dbo].[CodeWords] ([CodeClass], [CodeType], [CodeWord])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DBSecurity]'
GO
CREATE TABLE [dbo].[DBSecurity]
(
[DBSecurityID] [int] NOT NULL IDENTITY(1, 1),
[ObjectType] [varchar] (10) NULL,
[ObjectKey] [varchar] (100) NULL,
[Tag] [varchar] (10) NULL,
[PermissionType] [varchar] (10) NULL,
[AllowUsers] [varchar] (1000) NULL,
[DenyUsers] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DBSecurity] on [dbo].[DBSecurity]'
GO
ALTER TABLE [dbo].[DBSecurity] ADD CONSTRAINT [PK_DBSecurity] PRIMARY KEY CLUSTERED  ([DBSecurityID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_DBSecurity] on [dbo].[DBSecurity]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_DBSecurity] ON [dbo].[DBSecurity] ([ObjectType], [ObjectKey], [Tag], [PermissionType])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[DBVersion]'
GO
CREATE TABLE [dbo].[DBVersion]
(
[DBVersionID] [int] NOT NULL IDENTITY(1, 1),
[Version] [decimal] (18, 4) NULL,
[UpdatedOn] [datetime] NULL,
[MCVApp1] [varchar] (50) NULL,
[MCVNum1] [varchar] (50) NULL,
[MCVApp2] [varchar] (50) NULL,
[MCVNum2] [varchar] (50) NULL,
[MCVApp3] [varchar] (50) NULL,
[MCVNum3] [varchar] (50) NULL,
[MCVApp4] [varchar] (50) NULL,
[MCVNum4] [varchar] (50) NULL,
[MCVApp5] [varchar] (50) NULL,
[MCVNum5] [varchar] (50) NULL,
[MCVApp6] [varchar] (50) NULL,
[MCVNum6] [varchar] (50) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_DBVersion] on [dbo].[DBVersion]'
GO
ALTER TABLE [dbo].[DBVersion] ADD CONSTRAINT [PK_DBVersion] PRIMARY KEY CLUSTERED  ([DBVersionID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[PIDUnitType]'
GO
CREATE TABLE [dbo].[PIDUnitType]
(
[PIDUnitTypeID] [int] NOT NULL,
[TypeCode] [varchar] (50) NULL,
[PIDUnitFolderTemplate] [varchar] (1000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_PIDUnitType] on [dbo].[PIDUnitType]'
GO
ALTER TABLE [dbo].[PIDUnitType] ADD CONSTRAINT [PK_PIDUnitType] PRIMARY KEY CLUSTERED  ([PIDUnitTypeID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[sysRowLocks]'
GO
CREATE TABLE [dbo].[sysRowLocks]
(
[sysRowLockID] [int] NOT NULL IDENTITY(1, 1),
[IDField] [varchar] (50) NULL,
[IDValue] [int] NULL,
[CreatedOn] [datetime] NULL,
[CreatedBy] [varchar] (50) NULL,
[LastModifiedOn] [datetime] NULL,
[LastModifiedBy] [varchar] (50) NULL,
[OpenedBy] [varchar] (50) NULL,
[OpenedFromPC] [varchar] (50) NULL,
[OpenedFromApp] [varchar] (50) NULL,
[OpenedOn] [datetime] NULL,
[ClosedOn] [datetime] NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK_sysRowLocks] on [dbo].[sysRowLocks]'
GO
ALTER TABLE [dbo].[sysRowLocks] ADD CONSTRAINT [PK_sysRowLocks] PRIMARY KEY CLUSTERED  ([sysRowLockID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating index [IX_sysRowLocks] on [dbo].[sysRowLocks]'
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_sysRowLocks] ON [dbo].[sysRowLocks] ([IDField], [IDValue])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[SystemOptions]'
GO
CREATE TABLE [dbo].[SystemOptions]
(
[SystemOptionID] [int] NOT NULL IDENTITY(1, 1),
[CompanyName] [nvarchar] (1000) NULL,
[CompanyAddress] [nvarchar] (4000) NULL
)
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating primary key [PK__SystemOp__2AA044A9534D60F1] on [dbo].[SystemOptions]'
GO
ALTER TABLE [dbo].[SystemOptions] ADD CONSTRAINT [PK__SystemOp__2AA044A9534D60F1] PRIMARY KEY CLUSTERED  ([SystemOptionID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating [dbo].[sp_GetTablePerms]'
GO






CREATE     PROCEDURE [dbo].[sp_GetTablePerms] @txtTblName varchar(50) AS

DECLARE @intPerms       INT

/* Make sure table name passed as parameter */
IF @txtTblName Is Null BEGIN
   SELECT -1 AS Permission,@txttblname as obj
   RETURN (-1)
END

/* Check for invalid table name */
IF (SELECT OBJECT_ID(@txtTblName)) IS NULL BEGIN
   SELECT -1 AS Permission,@txttblname as obj
   RETURN (-1)
END

/* Calculate permissions and return to calling program */
SELECT @intPerms = PERMISSIONS(OBJECT_ID(@txtTblName))
SELECT @intPerms As Permission,@txttblname as Obj

RETURN (@intPerms)







GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding constraints to [dbo].[ItemVMS]'
GO
ALTER TABLE [dbo].[ItemVMS] ADD CONSTRAINT [CK_ItemVMS] CHECK (([itemid] IS NULL AND [subcatid] IS NOT NULL OR [itemid] IS NOT NULL AND [subcatid] IS NULL))
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtl]'
GO
ALTER TABLE [dbo].[PIDCtl] WITH NOCHECK ADD
CONSTRAINT [FK_PIDCtl_CtlItems] FOREIGN KEY ([CtlItemID]) REFERENCES [dbo].[CtlItems] ([CtlItemID]) ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ItemVMS]'
GO
ALTER TABLE [dbo].[ItemVMS] WITH NOCHECK ADD
CONSTRAINT [FK_ItemVMS_Items] FOREIGN KEY ([ItemID]) REFERENCES [dbo].[Items] ([ItemID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ItemSpecs]'
GO
ALTER TABLE [dbo].[ItemSpecs] WITH NOCHECK ADD
CONSTRAINT [FK_ItemSpecs_Specs] FOREIGN KEY ([StanSpecID]) REFERENCES [dbo].[StanSpecs] ([StanSpecID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_ItemSpecs_ItemVMS] FOREIGN KEY ([ItemVMSID]) REFERENCES [dbo].[ItemVMS] ([ItemVMSID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[CtlItems]'
GO
ALTER TABLE [dbo].[CtlItems] ADD
CONSTRAINT [FK_CtlItems_CtlCat] FOREIGN KEY ([CtlCatID]) REFERENCES [dbo].[CtlCat] ([CtlCatID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_CtlItems_CtlMtg] FOREIGN KEY ([MtgCPID]) REFERENCES [dbo].[CtlMtg] ([CtlMtgID]),
CONSTRAINT [FK_CtlItems_CtlMtg1] FOREIGN KEY ([MtgMBID]) REFERENCES [dbo].[CtlMtg] ([CtlMtgID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[CtlItemTermSet]'
GO
ALTER TABLE [dbo].[CtlItemTermSet] ADD
CONSTRAINT [FK_CtlItemTermSet_CtlItems] FOREIGN KEY ([CtlItemID]) REFERENCES [dbo].[CtlItems] ([CtlItemID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtlTerm]'
GO
ALTER TABLE [dbo].[PIDCtlTerm] ADD
CONSTRAINT [FK_PIDCtlTerm_CtlItemTermSet] FOREIGN KEY ([CtlItemTermSetID]) REFERENCES [dbo].[CtlItemTermSet] ([CtlItemTermSetID]),
CONSTRAINT [FK_PIDCtlTerm_PIDCtl] FOREIGN KEY ([PIDCtlID]) REFERENCES [dbo].[PIDCtl] ([PIDCtlID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_PIDCtlTerm_PIDCtlWire] FOREIGN KEY ([PIDCtlBusID]) REFERENCES [dbo].[PIDCtlBus] ([PIDCtlBusID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[CtlMtg]'
GO
ALTER TABLE [dbo].[CtlMtg] ADD
CONSTRAINT [FK_CtlMtg_CtlMtg] FOREIGN KEY ([CtlMtgID]) REFERENCES [dbo].[CtlMtg] ([CtlMtgID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[CtlMtgItem]'
GO
ALTER TABLE [dbo].[CtlMtgItem] ADD
CONSTRAINT [FK_CtlMtgItem_CtlMtg] FOREIGN KEY ([CtlMtgID]) REFERENCES [dbo].[CtlMtg] ([CtlMtgID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_CtlMtgItem_Items] FOREIGN KEY ([ItemID]) REFERENCES [dbo].[Items] ([ItemID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[CtlTerminal]'
GO
ALTER TABLE [dbo].[CtlTerminal] ADD
CONSTRAINT [FK_CtlTerminal_CtlTerminalSet] FOREIGN KEY ([CtlTerminalSetID]) REFERENCES [dbo].[CtlTerminalSet] ([CtlTerminalSetID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DesCPGroupCP]'
GO
ALTER TABLE [dbo].[DesCPGroupCP] ADD
CONSTRAINT [FK_DesCPGroupCP_DesChkPoint] FOREIGN KEY ([DesChkPointID]) REFERENCES [dbo].[DesChkPoint] ([DesChkPointID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_DesCPGroupCP_DesCPGroup] FOREIGN KEY ([DesCPGroupID]) REFERENCES [dbo].[DesCPGroup] ([DesCPGroupID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DesDocCust]'
GO
ALTER TABLE [dbo].[DesDocCust] ADD
CONSTRAINT [FK_DesDocCust_DesDocs] FOREIGN KEY ([DesDocID]) REFERENCES [dbo].[DesDocs] ([DesDocID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DesDocGen]'
GO
ALTER TABLE [dbo].[DesDocGen] ADD
CONSTRAINT [FK_DesDocGen_DesDocs] FOREIGN KEY ([DesDocID]) REFERENCES [dbo].[DesDocs] ([DesDocID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_DesDocGen_DesDocTemp] FOREIGN KEY ([DesDocTempID]) REFERENCES [dbo].[DesDocTemp] ([DesDocTempID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DesDocs]'
GO
ALTER TABLE [dbo].[DesDocs] ADD
CONSTRAINT [FK_DesDocs_DesDocType] FOREIGN KEY ([DesDocGrpID]) REFERENCES [dbo].[DesDocGrp] ([DesDocGrpID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DesDocParam]'
GO
ALTER TABLE [dbo].[DesDocParam] ADD
CONSTRAINT [FK_DesDocParam_DesDocs] FOREIGN KEY ([DesDocID]) REFERENCES [dbo].[DesDocs] ([DesDocID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_DesDocParam_DesParams] FOREIGN KEY ([DesParamID]) REFERENCES [dbo].[DesParams] ([DesParamID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DesTabParam]'
GO
ALTER TABLE [dbo].[DesTabParam] ADD
CONSTRAINT [FK_DesTabParam_DesParams] FOREIGN KEY ([DesParamID]) REFERENCES [dbo].[DesParams] ([DesParamID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_DesTabParam_DesTables] FOREIGN KEY ([DesTableID]) REFERENCES [dbo].[DesTables] ([DesTableID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDUParams]'
GO
ALTER TABLE [dbo].[PIDUParams] ADD
CONSTRAINT [FK_PIDUParams_DesParams] FOREIGN KEY ([DesParamID]) REFERENCES [dbo].[DesParams] ([DesParamID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_PIDUParams_PIDUnit] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DesTableData]'
GO
ALTER TABLE [dbo].[DesTableData] ADD
CONSTRAINT [FK_TFDesData_TFDesTabCols] FOREIGN KEY ([DesTableColID]) REFERENCES [dbo].[DesTableCols] ([DesTableColID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_DesTableData_DesTableRows] FOREIGN KEY ([DesTableRowID]) REFERENCES [dbo].[DesTableRows] ([DesTableRowID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DesTableCols]'
GO
ALTER TABLE [dbo].[DesTableCols] ADD
CONSTRAINT [FK_TFDesTabCols_TFDesTables] FOREIGN KEY ([DesTableID]) REFERENCES [dbo].[DesTables] ([DesTableID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DesTableRows]'
GO
ALTER TABLE [dbo].[DesTableRows] ADD
CONSTRAINT [FK_DesTableRows_DesTables] FOREIGN KEY ([DesTableID]) REFERENCES [dbo].[DesTables] ([DesTableID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DocDistriCodeDep]'
GO
ALTER TABLE [dbo].[DocDistriCodeDep] ADD
CONSTRAINT [FK_DosDistriCodeDep_DosDistriCodeDep] FOREIGN KEY ([DocDistriCodeID]) REFERENCES [dbo].[DocDistriCode] ([DocDistriCodeID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DrgItemBOM]'
GO
ALTER TABLE [dbo].[DrgItemBOM] ADD
CONSTRAINT [FK_DrgItemBOM_DrgItems] FOREIGN KEY ([DrgItemID]) REFERENCES [dbo].[DrgItems] ([DrgItemID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DrgItemCalc]'
GO
ALTER TABLE [dbo].[DrgItemCalc] ADD
CONSTRAINT [FK_DrgItemCalc_DrgItems] FOREIGN KEY ([DrgItemID]) REFERENCES [dbo].[DrgItems] ([DrgItemID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DrgItemParam]'
GO
ALTER TABLE [dbo].[DrgItemParam] ADD
CONSTRAINT [FK_DrgItemParam_DrgItems] FOREIGN KEY ([DrgItemID]) REFERENCES [dbo].[DrgItems] ([DrgItemID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[DrgItems]'
GO
ALTER TABLE [dbo].[DrgItems] ADD
CONSTRAINT [FK_DrgItems_StdDrg] FOREIGN KEY ([StdDrgID]) REFERENCES [dbo].[StdDrg] ([StdDrgID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_DrgItems_ProDocu] FOREIGN KEY ([ProDocuID]) REFERENCES [dbo].[ProDocu] ([ProDocuID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[FileStoreDir]'
GO
ALTER TABLE [dbo].[FileStoreDir] ADD
CONSTRAINT [FK_FileStoreDir_FileStore] FOREIGN KEY ([FileStoreID]) REFERENCES [dbo].[FileStore] ([FileStoreID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ItemCodeDef]'
GO
ALTER TABLE [dbo].[ItemCodeDef] ADD
CONSTRAINT [FK_ItemCodeGrpVal_ItemSubCats] FOREIGN KEY ([SubCATID]) REFERENCES [dbo].[ItemSubCats] ([SubCatID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtlItem]'
GO
ALTER TABLE [dbo].[PIDCtlItem] ADD
CONSTRAINT [FK_PIDCtlItem_Items] FOREIGN KEY ([ItemID]) REFERENCES [dbo].[Items] ([ItemID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_PIDCtlItem_PIDCtl] FOREIGN KEY ([PIDCtlID]) REFERENCES [dbo].[PIDCtl] ([PIDCtlID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFDesAssyMatItem]'
GO
ALTER TABLE [dbo].[TFDesAssyMatItem] ADD
CONSTRAINT [FK_TFDesAssyMatItem_Items] FOREIGN KEY ([ItemID]) REFERENCES [dbo].[Items] ([ItemID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_TFDesAssyMatItem_TFDesAssyMat] FOREIGN KEY ([TFDesAssyMatID]) REFERENCES [dbo].[TFDesAssyMat] ([TFDesAssyMatID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[Items]'
GO
ALTER TABLE [dbo].[Items] ADD
CONSTRAINT [FK_Items_ItemSubCats] FOREIGN KEY ([SubCatID]) REFERENCES [dbo].[ItemSubCats] ([SubCatID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ItemSubCatDef]'
GO
ALTER TABLE [dbo].[ItemSubCatDef] ADD
CONSTRAINT [FK_ItemSubCatDef_ItemSubCats] FOREIGN KEY ([SubCatID]) REFERENCES [dbo].[ItemSubCats] ([SubCatID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ItemVMSBOM]'
GO
ALTER TABLE [dbo].[ItemVMSBOM] ADD
CONSTRAINT [FK_ItemVMSBOM_ItemVMS] FOREIGN KEY ([ItemVMSID]) REFERENCES [dbo].[ItemVMS] ([ItemVMSID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_ItemVMSBOM_ItemVMS1] FOREIGN KEY ([ChildItemVMSID]) REFERENCES [dbo].[ItemVMS] ([ItemVMSID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtlBusPanel]'
GO
ALTER TABLE [dbo].[PIDCtlBusPanel] ADD
CONSTRAINT [FK_PIDCtlBusPanel_PIDCtlBus] FOREIGN KEY ([PIDCtlBusID]) REFERENCES [dbo].[PIDCtlBus] ([PIDCtlBusID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtlBusTerm]'
GO
ALTER TABLE [dbo].[PIDCtlBusTerm] ADD
CONSTRAINT [FK_PIDCtlBusTerm_PIDCtlBus] FOREIGN KEY ([PIDCtlBusID]) REFERENCES [dbo].[PIDCtlBus] ([PIDCtlBusID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtlBus]'
GO
ALTER TABLE [dbo].[PIDCtlBus] ADD
CONSTRAINT [FK_PIDCtlWire_PIDUnit] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtlConn]'
GO
ALTER TABLE [dbo].[PIDCtlConn] ADD
CONSTRAINT [FK_PIDCtlConn_PIDCtlCable] FOREIGN KEY ([PIDCtlCableID]) REFERENCES [dbo].[PIDCtlCable] ([PIDCtlCableID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_PIDCtlConn_PIDUnit] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtlCable]'
GO
ALTER TABLE [dbo].[PIDCtlCable] ADD
CONSTRAINT [FK_PIDCtlCable_PIDUnit] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtlDoc]'
GO
ALTER TABLE [dbo].[PIDCtlDoc] ADD
CONSTRAINT [FK_PIDCtlDrg_PIDUnit] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[PIDCtlPanel]'
GO
ALTER TABLE [dbo].[PIDCtlPanel] ADD
CONSTRAINT [FK_PIDCtlPanel_PIDUnit] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ProDocu]'
GO
ALTER TABLE [dbo].[ProDocu] ADD
CONSTRAINT [FK_ProDocu_DesDocs] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFDesAssyMat]'
GO
ALTER TABLE [dbo].[TFDesAssyMat] ADD
CONSTRAINT [FK_TFDesAssyMat_TFDesign] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_TFDesAssyMat_TFPartDef] FOREIGN KEY ([TFPartDefID]) REFERENCES [dbo].[TFPartDef] ([TFPartDefID]) ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFDesBOMGA]'
GO
ALTER TABLE [dbo].[TFDesBOMGA] ADD
CONSTRAINT [FK_TFDesBOMGA_TFDesign] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFDesBOMTank]'
GO
ALTER TABLE [dbo].[TFDesBOMTank] ADD
CONSTRAINT [FK_TFDesBOMTank_TFDesign] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFDesCompRef]'
GO
ALTER TABLE [dbo].[TFDesCompRef] ADD
CONSTRAINT [FK_TFDesCompRef_TFDesign] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_TFDesCompRef_TFCompDef] FOREIGN KEY ([TFCompDefID]) REFERENCES [dbo].[TFCompDef] ([TFCompDefID])
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFDesDefParam]'
GO
ALTER TABLE [dbo].[TFDesDefParam] ADD
CONSTRAINT [FK_TFDesDefParam_TFDesign] FOREIGN KEY ([PIDUnitID]) REFERENCES [dbo].[PIDUnit] ([PIDUnitID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[ProdocuRev]'
GO
ALTER TABLE [dbo].[ProdocuRev] ADD
CONSTRAINT [FK_ProdocuRev_ProDocu] FOREIGN KEY ([ProdocuID]) REFERENCES [dbo].[ProDocu] ([ProDocuID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[StdDrgParam]'
GO
ALTER TABLE [dbo].[StdDrgParam] ADD
CONSTRAINT [FK_StdDrgParam_StdDrg] FOREIGN KEY ([StdDrgID]) REFERENCES [dbo].[StdDrg] ([StdDrgID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFAssyDefBOM]'
GO
ALTER TABLE [dbo].[TFAssyDefBOM] ADD
CONSTRAINT [FK_TFAssyDefBOM_TFAssyDef] FOREIGN KEY ([TFAssyDefID]) REFERENCES [dbo].[TFAssyDef] ([TFAssyDefID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFCompDefParam]'
GO
ALTER TABLE [dbo].[TFCompDefParam] ADD
CONSTRAINT [FK_TFCompDefParam_TFAssyDef] FOREIGN KEY ([TFAssyDefID]) REFERENCES [dbo].[TFAssyDef] ([TFAssyDefID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_TFCompDefParam_TFCompDef] FOREIGN KEY ([TFCompDefID]) REFERENCES [dbo].[TFCompDef] ([TFCompDefID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFCompDefBOMParam]'
GO
ALTER TABLE [dbo].[TFCompDefBOMParam] ADD
CONSTRAINT [FK_TFCompDefBOMParam_TFAssyDefBOM] FOREIGN KEY ([TFAssyDefBOMID]) REFERENCES [dbo].[TFAssyDefBOM] ([TFAssyDefBOMID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_TFCompDefBOMParam_TFCompDefDetBOM] FOREIGN KEY ([TFCompDefDetBOMID]) REFERENCES [dbo].[TFCompDefDetBOM] ([TFCompDefDetBOMID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFCompDefActPack]'
GO
ALTER TABLE [dbo].[TFCompDefActPack] ADD
CONSTRAINT [FK_TFCompDefActPack_TFCompDef] FOREIGN KEY ([TFCompDefID]) REFERENCES [dbo].[TFCompDef] ([TFCompDefID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFCompDefDetBOM]'
GO
ALTER TABLE [dbo].[TFCompDefDetBOM] ADD
CONSTRAINT [FK_TFCompDefDetBOM_TFCompDef] FOREIGN KEY ([TFCompDefID]) REFERENCES [dbo].[TFCompDef] ([TFCompDefID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFCompDefEnt]'
GO
ALTER TABLE [dbo].[TFCompDefEnt] ADD
CONSTRAINT [FK_TFCompDefEnt_TFCompDef] FOREIGN KEY ([TFCompDefID]) REFERENCES [dbo].[TFCompDef] ([TFCompDefID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFCompDefParamGrp]'
GO
ALTER TABLE [dbo].[TFCompDefParamGrp] ADD
CONSTRAINT [FK_TFCompDefParamGrp_TFCompDef] FOREIGN KEY ([TFCompDefID]) REFERENCES [dbo].[TFCompDef] ([TFCompDefID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFCompDefShot]'
GO
ALTER TABLE [dbo].[TFCompDefShot] ADD
CONSTRAINT [FK_TFCompDefShot_TFCompDef] FOREIGN KEY ([TFCompDefID]) REFERENCES [dbo].[TFCompDef] ([TFCompDefID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFCompDefStdFF]'
GO
ALTER TABLE [dbo].[TFCompDefStdFF] ADD
CONSTRAINT [FK_TFCompDefStdFF_TFCompDef] FOREIGN KEY ([TFCompDefID]) REFERENCES [dbo].[TFCompDef] ([TFCompDefID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFCompDefAction]'
GO
ALTER TABLE [dbo].[TFCompDefAction] ADD
CONSTRAINT [FK_TFCompDefAction_TFCompDef] FOREIGN KEY ([TFCompDefActPackID]) REFERENCES [dbo].[TFCompDefActPack] ([TFCompDefActPackID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFDesPackList]'
GO
ALTER TABLE [dbo].[TFDesPackList] ADD
CONSTRAINT [FK_TFDesPackList_TFDesAssyMat] FOREIGN KEY ([TFDesAssyMatID]) REFERENCES [dbo].[TFDesAssyMat] ([TFDesAssyMatID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFDesCompRefParam]'
GO
ALTER TABLE [dbo].[TFDesCompRefParam] ADD
CONSTRAINT [FK_TFDesCompRefParam_TFDesCompRef] FOREIGN KEY ([TFDesCompRefID]) REFERENCES [dbo].[TFDesCompRef] ([TFDesCompRefID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFNestItems]'
GO
ALTER TABLE [dbo].[TFNestItems] ADD
CONSTRAINT [FK_TFNestReqItems_TFNest] FOREIGN KEY ([TFNestID]) REFERENCES [dbo].[TFNest] ([TFNestID]) ON DELETE CASCADE ON UPDATE CASCADE,
CONSTRAINT [FK_TFNestReqItems_TFNestReq] FOREIGN KEY ([TFNestReqID]) REFERENCES [dbo].[TFNestReq] ([TFNestReqID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFNestSheet]'
GO
ALTER TABLE [dbo].[TFNestSheet] ADD
CONSTRAINT [FK_TFNestSheet_TFNest] FOREIGN KEY ([TFNestID]) REFERENCES [dbo].[TFNest] ([TFNestID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Adding foreign keys to [dbo].[TFPartDef]'
GO
ALTER TABLE [dbo].[TFPartDef] ADD
CONSTRAINT [FK_TFPartDef_TFPartDefCat] FOREIGN KEY ([TFPartDefCatID]) REFERENCES [dbo].[TFPartDefCat] ([TFPartDefCatID]) ON DELETE CASCADE ON UPDATE CASCADE
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
PRINT N'Creating extended properties'
GO
DECLARE @xp tinyint
SELECT @xp=2
EXEC sp_addextendedproperty N'MS_DefaultView', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Filter', NULL, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_LinkChildFields', N'MatDepID', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_LinkMasterFields', N'MatDepID', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_OrderBy', NULL, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_OrderByOn', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp tinyint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_Orientation', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_SubdatasheetName', N'dbo.ProdSec', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_TableMaxRecords', 10000, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsReq'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsReq'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsReq'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsReq'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsReq'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsReq'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsWO'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsWO'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsWO'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsWO'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsWO'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'AcceptsWO'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'CampusID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'CampusID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'CampusID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'DepCode'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'DepCode'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'DepCode'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'DepName'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'DepName'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=1530
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'DepName'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'GivesReq'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'GivesReq'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'GivesReq'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'HasNC'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'HasNC'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'HasNC'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'IsShop'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'IsShop'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'IsShop'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'IsShop'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'IsShop'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'IsShop'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'IsStore'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'IsStore'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'IsStore'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'LastVouchNum'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'LastVouchNum'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'LastVouchNum'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'LastVouchNum'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'LastVouchNum'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'LastVouchNum'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'MatDepID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=1
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'MatDepID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'DepsMat', 'COLUMN', N'MatDepID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Description', N'0=Std, 1=WO, 2=RO, 3=TE', 'SCHEMA', N'dbo', 'TABLE', N'FileStoreDir', 'COLUMN', N'PIDUnitType1'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'ItemSpecs', 'COLUMN', N'ItemSpecID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'ItemSpecs', 'COLUMN', N'ItemSpecID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'ItemSpecs', 'COLUMN', N'ItemSpecID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp tinyint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_Orientation', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Description', N'CP=1 means its for RTCC, otherwise MB', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'CP'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'CP'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'CP'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'CP'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'CtlItemID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'CtlItemID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'CtlItemID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'DescripPrefix'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'DescripPrefix'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'DescripPrefix'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'DescripSuffix'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'DescripSuffix'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'DescripSuffix'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'Legend'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'Legend'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'Legend'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'PIDCtlID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'PIDCtlID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'PIDCtlID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'PIDUnitID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'PIDUnitID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'PIDUnitID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'Price'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'Price'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'Price'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'Qty'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'Qty'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtl', 'COLUMN', N'Qty'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Description', N'1 = Internal (MB/CP), 2 = External (DM), 3 = Field Area (TF)', 'SCHEMA', N'dbo', 'TABLE', N'PIDCtlPanel', 'COLUMN', N'PanelType'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp tinyint
SELECT @xp=2
EXEC sp_addextendedproperty N'MS_DefaultView', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Filter', NULL, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_LinkChildFields', N'WorkOrderID', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_LinkMasterFields', N'WorkOrderID', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_OrderBy', NULL, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_OrderByOn', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp tinyint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_Orientation', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_SubdatasheetName', N'dbo.WorkOrders', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_TableMaxRecords', 10000, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', NULL, NULL
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'Descrip'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'Descrip'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'Descrip'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'Descrip'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'Descrip'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'Descrip'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'DesignDate'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'DesignDate'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'DesignDate'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'FileNum'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'FileNum'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'FileNum'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'IsCompleted'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'IsCompleted'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'IsCompleted'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'IsCompleted'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'IsCompleted'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'IsCompleted'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp bit
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnHidden', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'PIDUnitID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=0
EXEC sp_addextendedproperty N'MS_ColumnOrder', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'PIDUnitID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
DECLARE @xp smallint
SELECT @xp=-1
EXEC sp_addextendedproperty N'MS_ColumnWidth', @xp, 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'PIDUnitID'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_DisplayControl', N'109', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'Remarks'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Format', N'', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'Remarks'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_IMEMode', N'0', 'SCHEMA', N'dbo', 'TABLE', N'PIDUnit', 'COLUMN', N'Remarks'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
EXEC sp_addextendedproperty N'MS_Description', N'0=Not Detached, 1=Can Detach, 2=Always Detached', 'SCHEMA', N'dbo', 'TABLE', N'TFAssyDef', 'COLUMN', N'DetachType'
GO
IF @@ERROR<>0 AND @@TRANCOUNT>0 ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT=0 BEGIN INSERT INTO #tmpErrors (Error) SELECT 1 BEGIN TRANSACTION END
GO
IF EXISTS (SELECT * FROM #tmpErrors) ROLLBACK TRANSACTION
GO
IF @@TRANCOUNT>0 BEGIN
PRINT 'The database update succeeded'
COMMIT TRANSACTION
END
ELSE PRINT 'The database update failed'
GO
DROP TABLE #tmpErrors
GO
